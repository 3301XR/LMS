package com.tradewave.lms

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
