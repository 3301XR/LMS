import 'package:flutter/material.dart';

import 'app/app.dart';
import 'app/dic.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await AppDic.setup();
  runApp(const MyApp());
}
