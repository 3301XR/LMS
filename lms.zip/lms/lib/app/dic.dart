import 'package:get/get.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/repositories/employee_repository.dart';
import 'package:lms/app/modules/super_admin/repositories/super_admin_repository.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppDic {
  static final find = Get.find;
  static setup() async {
    await Get.putAsync<SharedPreferences>(
        () => SharedPreferences.getInstance());

    Get.lazyPut<AuthRepository>(() => AuthRepositoryImpl(find()), fenix: true);
    Get.lazyPut<EmployeeRepository>(() => EmployeeRepositoryImpl(find()),
        fenix: true);
    Get.lazyPut<AdminRepository>(() => AdminRepositoryImpl(find()),
        fenix: true);
    Get.lazyPut<SuperAdminRepository>(() => SuperAdminRepositoryImpl(find()),
        fenix: true);
  }
}
