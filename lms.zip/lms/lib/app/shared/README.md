# Shared

Shared Kernel of the app that can be shared across the app.
Usually contains utility functions, constant values, base classes and contracts.