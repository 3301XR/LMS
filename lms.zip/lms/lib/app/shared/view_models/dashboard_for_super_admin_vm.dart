import 'package:get/get.dart';
import 'package:lms/app/modules/admin/models/responses/operator_dashboard_response.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/models/application.dart';
import 'package:lms/app/modules/super_admin/repositories/super_admin_repository.dart';

import '../../modules/auth/models/user.dart';

class DashboardForSuperAdminController extends GetxController {
  final SuperAdminRepository _superAdminRepository =
      Get.find<SuperAdminRepository>();

  final pendingApplicationList = <Application>[].obs;

  final user = Rxn<User>();
  final dashboard = Rxn<DashboardResponse>();

  onGetProfile() async {
    final AuthRepository authRepository = Get.find<AuthRepository>();

    final loginResponse = await authRepository.getLoginResponse();

    loginResponse.fold((l) => null, (r) => user.value = r.data);
  }

  onGetDashboard() async {
    final loginResponse = await _superAdminRepository.getSuperAdminDashboard();

    loginResponse.fold((l) => null, (r) => dashboard.value = r);
  }

  getPendingMyApplicationList() async {
    final response = await _superAdminRepository.getPendingApplication();

    response.fold((l) => null,
        (r) => pendingApplicationList.assignAll(r.applications!.reversed));
  }

  @override
  onInit() async {
    super.onInit();
    await onGetProfile();
    await getPendingMyApplicationList();
    await onGetDashboard();
  }
}
