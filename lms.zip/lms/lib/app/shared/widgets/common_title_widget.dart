import 'package:flutter/material.dart';

import '../values/colors.dart';

class CommonTitleWidget extends StatelessWidget {
  final double? height;
  final double? width;
  final String? title;
  const CommonTitleWidget({Key? key, this.height, this.width, this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        height: height,
        width: width,
        decoration: BoxDecoration(
            color: AppTheme.titleColor,
            borderRadius: BorderRadius.circular(10)),
        child: Center(
          child: Text(
            title!,
            textAlign: TextAlign.center,
            style: const TextStyle(
                color: Colors.white, fontSize: 22, fontWeight: FontWeight.w600),
          ),
        ));
  }
}
