import 'package:flutter/material.dart';

import '../values/colors.dart';

class CommonCardWidget extends StatelessWidget {
  final double? height;
  final double? width;
  final String? title;
  final String? dataInfo;
  final IconData? icon;
  void Function()? onTap;
  CommonCardWidget(
      {Key? key,
      this.height,
      this.width,
      this.title,
      this.onTap,
      this.icon,
      this.dataInfo})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
          height: height,
          width: width,
          decoration: BoxDecoration(
              color: AppTheme.commonContainerColor,
              borderRadius: BorderRadius.circular(10)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 50,
                color: Colors.white,
              ),
              const SizedBox(
                width: 10,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    dataInfo!,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w600),
                  ),
                  Text(
                    title!,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ],
          )),
    );
  }
}
