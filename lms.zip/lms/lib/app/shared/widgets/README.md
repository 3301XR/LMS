# Widgets

The shared widgets are those that can be used by all of the modules in the application.