# Failures

Contains all the failure objects used in the application regardless of modules.