import 'package:flutter/material.dart';

class AppTheme {
  static Color primaryColor = const Color(0xff683091);
  static const MaterialColor primarySwatchColor = MaterialColor(
    0xff683091,
    <int, Color>{
      50: Color(0xff683091),
      100: Color(0xff683091),
      200: Color(0xff683091),
      300: Color(0xff683091),
      400: Color(0xff683091),
      500: Color(0xff683091),
      600: Color(0xff683091),
      700: Color(0xff683091),
      800: Color(0xff683091),
      900: Color(0xff683091),
    },
  );
  static const Color primaryColorConst = Color(0xffB7C3E4);
  static const Color secondaryColor = Color(0XFF20A6FF);
  static Color primaryFontColor = const Color(0XFF707070);
  static Color secondaryFontColor = const Color(0xffBABABA);
  static Color titleColor = const Color(0XFF683091);
  static Color commonContainerColor = const Color(0XFF8AC642);
  static Color errorFontColor = const Color(0xffC12037);
  static final ThemeData primaryTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: primaryColor,
    scaffoldBackgroundColor: Colors.white,
    textTheme: TextTheme(
        bodyText2: TextStyle(
      color: primaryFontColor,
    )),
    primarySwatch: primarySwatchColor,
    unselectedWidgetColor: const Color(0xff20A6FF),
    //appBarTheme: AppBarTheme(backgroundColor: primaryColor)
  );
}
