# Values

Contains values that are used throughout the app.