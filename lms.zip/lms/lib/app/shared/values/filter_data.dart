class ApplicationStatus {
  final String? key;
  final String name;

  ApplicationStatus({this.key, required this.name});

  static final filterList = <ApplicationStatus>[
    ApplicationStatus(key: "", name: "সব"),
    ApplicationStatus(key: "0", name: "প্রত্যাখ্যাত"),
    ApplicationStatus(key: "1", name: "অনুমোদিত"),
    ApplicationStatus(key: null, name: "অপেক্ষমাণ"),
  ];
}
