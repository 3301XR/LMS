abstract class ApiStrings {
  static const String baseUrl = 'https://factanalyzer.com';
  static const String apiUrl = '$baseUrl/api';
}
