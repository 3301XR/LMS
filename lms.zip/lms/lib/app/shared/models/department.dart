class Designation {
  String name;
  Designation(this.name);

  static var designationList = [
    Designation('সিনিয়র সচিব'),
    Designation('অতিরিক্ত সচিব'),
    Designation('মাননীয় প্রতিমন্ত্রীর একান্ত সচিব'),
    Designation('একান্ত সচিব'),
    Designation('সিনিয়র সচিবের একান্ত সচিব'),
    Designation('যুগ্মসচিব'),
    Designation('উপসচিব'),
    Designation('সিনিয়র সহকারী সচিব'),
    Designation('সহকারী সচিব'),
    Designation('সিনিয়র সিস্টেম এনালিস্ট'),
    Designation('সিনিয়র মেইন্টেনেন্স ইঞ্জিনিয়ার'),
    Designation('সিস্টেম এনালিস্ট'),
    Designation('প্রোগ্রামার'),
    Designation('সহকারী মেইন্টেনেন্স ইঞ্জিনিয়ার'),
  ];
}
