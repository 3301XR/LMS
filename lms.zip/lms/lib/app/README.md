# App

This is the root of the app.
Usually contains the application entry-point and dependency injection container. 


