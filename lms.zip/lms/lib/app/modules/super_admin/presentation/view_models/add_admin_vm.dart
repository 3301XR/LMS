import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/modules/auth/models/requests/create_update_user_request.dart';
import 'package:lms/app/modules/super_admin/repositories/super_admin_repository.dart';

import '../../../../shared/models/department.dart';
import '../../../../shared/models/branch.dart';

class AddAdminVM extends GetxController {
  final AdminRepository _adminRepository = Get.find<AdminRepository>();
  final selectedBranch = Rxn<Branch>();
  final selectedDesignation = Rxn<Designation>();

  var userNameController = TextEditingController();

  var phoneNumberController = TextEditingController();

  var emailController = TextEditingController();

  var passwordController = TextEditingController();

  var validateBranch = false.obs;

  var validateDesignation = false.obs;

  addOperator() async {
    final response =
        await _adminRepository.createOperator(CreateUpdateUserRequest(
      username: userNameController.text,
      firstName: userNameController.text,
      phone: phoneNumberController.text,
      email: emailController.text,
      password: passwordController.text,
      department: selectedDesignation.value!.name,
      branch: selectedBranch.value!.name,
      role: 2,
      isActive: 1,
    ));

    response.fold((l) => Get.snackbar("Error", l.message), (r) {
      Get.back();
      Get.snackbar("Success", r.message!);
    });
  }
}
