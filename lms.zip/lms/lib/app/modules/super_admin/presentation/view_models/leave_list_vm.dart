import 'package:get/get.dart';
import 'package:lms/app/modules/employee/models/application.dart';
import 'package:lms/app/modules/super_admin/repositories/super_admin_repository.dart';
import 'package:lms/app/shared/controllers/base_controller.dart';

class LeaveListVm extends BaseController {
  final SuperAdminRepository _superAdminRepository =
      Get.find<SuperAdminRepository>();

  final leaveList = <Application>[].obs;
  final allLeaveList = <Application>[].obs;

  onGetLeaveList() async {
    isLoading.value = true;
    final response = await _superAdminRepository.getTotalLeaveList();
    isLoading.value = false;
    response.fold(
      (l) => null,
      (r) {
        leaveList.assignAll(r.applications?.reversed ?? []);
        allLeaveList.assignAll(r.applications?.reversed ?? []);
      },
    );
  }

  @override
  onInit() async {
    super.onInit();
    await onGetLeaveList();
  }

  void onSearch(String v) {
    leaveList.assignAll(allLeaveList
        .where((p0) => p0.toJson().toLowerCase().contains(v.toLowerCase())));
  }
}
