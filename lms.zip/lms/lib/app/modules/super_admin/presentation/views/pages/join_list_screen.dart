import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/modules/super_admin/presentation/view_models/leave_list_vm.dart';
import 'package:lms/app/shared/widgets/center_loading_indicator.dart';

import '../../../../admin/presentation/view_models/join_list_vm.dart';

class JoinListScreen extends StatelessWidget {
  JoinListScreen({Key? key}) : super(key: key) {
    controller = Get.put(JoinListVm());
  }

  late final JoinListVm controller;

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'কর্মরত',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
        elevation: 0,
      ),
      body: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    onChanged: (v) {
                      controller.onSearch(v);
                    },
                    decoration: InputDecoration(
                        contentPadding: const EdgeInsets.only(left: 20),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5),
                            borderSide: const BorderSide(
                              color: Colors.grey,
                            )),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5),
                            borderSide: const BorderSide(
                              color: Colors.grey,
                            )),
                        hintText: "Search"),
                  ),
                ),
              ),
            ],
          ),
          Expanded(
            child: Obx(() {
              return controller.isLoading.value
                  ? const CenterLoadingIndicator()
                  : Obx(() {
                      return controller.joinListResponse.isEmpty
                          ? const Center(
                              child: Text('Nothing to show'),
                            )
                          : ListView.builder(
                              itemCount: controller.joinListResponse.length,
                              itemBuilder: (context, index) {
                                final item = controller.joinListResponse[index];
                                return Padding(
                                  padding: const EdgeInsets.only(
                                      left: 8, right: 8, top: 5, bottom: 5),
                                  child: Container(
                                    padding: const EdgeInsets.only(
                                        left: 10, right: 10, top: 5, bottom: 5),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.grey.withOpacity(0.5),
                                          spreadRadius: 1,
                                          blurRadius: 1,
                                          offset: const Offset(1,
                                              1), // changes position of shadow
                                        ),
                                      ],
                                      color: Colors.white,
                                    ),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  const Text(
                                                    'নাম: ',
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontSize: 12),
                                                  ),
                                                  Flexible(
                                                    child: Text(
                                                      controller
                                                              .joinListResponse[
                                                                  index]
                                                              .username ??
                                                          '',
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: const TextStyle(
                                                          fontSize: 12),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Row(
                                                children: [
                                                  const Text(
                                                    'ইমেইল: ',
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontSize: 12),
                                                  ),
                                                  Flexible(
                                                    child: Text(
                                                      controller
                                                              .joinListResponse[
                                                                  index]
                                                              .email ??
                                                          '',
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: const TextStyle(
                                                          fontSize: 12),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Row(
                                                children: [
                                                  const Text(
                                                    'মোবাইল: ',
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontSize: 12),
                                                  ),
                                                  Flexible(
                                                    child: Text(
                                                      controller
                                                              .joinListResponse[
                                                                  index]
                                                              .phone ??
                                                          '',
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: const TextStyle(
                                                          fontSize: 12),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                    });
            }),
          ),
        ],
      ),
    );
  }
}
