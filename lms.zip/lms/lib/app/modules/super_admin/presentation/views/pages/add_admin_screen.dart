import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/shared/models/branch.dart';
import 'package:lms/app/shared/models/department.dart';
import 'package:lms/app/shared/values/colors.dart';

import '../../../../admin/presentation/views/widgets/auth_field_widget.dart';
import '../../view_models/add_admin_vm.dart';

class AddAdminScreen extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();

  AddAdminScreen({Key? key}) : super(key: key);
  final AddAdminVM controller = Get.put(AddAdminVM());

  @override
  Widget build(BuildContext context) {
    var sizedBox = const SizedBox(
      height: 10,
    );
    return Scaffold(
      appBar: AppBar(
        title: const Text('অপারেটর যুক্ত করুন'),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 15.0, right: 15.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                sizedBox,
                sizedBox,
                MyAuthFormField(
                  labelText: 'ব্যবহারকারীর নাম',
                  hinText: 'ব্যবহারকারীর নাম',
                  controller: controller.userNameController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'ব্যবহারকারীর নাম দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                MyAuthFormField(
                  labelText: 'মোবাইল',
                  hinText: '01700000000',
                  controller: controller.phoneNumberController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'মোবাইল নম্বর দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                MyAuthFormField(
                  labelText: 'ইমেইল',
                  hinText: 'xxx@mail.com',
                  controller: controller.emailController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'ইমেইল দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                MyAuthFormField(
                  labelText: 'পাসওয়ার্ড',
                  hinText: '********',
                  obscureText: true,
                  maxLines: 1,
                  controller: controller.passwordController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'পাসওয়ার্ড দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                const Text(
                  'পদবি',
                  style: TextStyle(),
                ),
                Obx(() {
                  return Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(5.0),
                      border: Border.all(
                          color: controller.validateDesignation.value == true
                              ? Colors.red
                              : Colors.grey),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 18.0, right: 18.0),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<Designation>(
                            isExpanded: true,
                            alignment: Alignment.center,
                            value: controller.selectedDesignation.value,
                            icon: const Icon(
                              Icons.keyboard_arrow_down,
                              color: AppTheme.primaryColorConst,
                              size: 30,
                            ),
                            elevation: 16,
                            style: TextStyle(
                                fontSize: 13, color: Colors.grey[800]),
                            onChanged: (Designation? newValue) {
                              controller.selectedDesignation.value = newValue!;
                              controller.validateDesignation.value = false;
                            },
                            hint: const Text(
                              "নির্বাচন করুণ",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.grey),
                            ),
                            items: Designation.designationList.map((e) {
                              return DropdownMenuItem<Designation>(
                                value: e,
                                child: Text(e.name),
                              );
                            }).toList()),
                      ),
                    ),
                  );
                }),
                sizedBox,
                const Text(
                  'শাখা',
                  style: TextStyle(),
                ),
                Obx(() {
                  return Container(
                      height: 40,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5.0),
                        border: Border.all(
                            color: controller.validateBranch.value == true &&
                                    controller.selectedBranch.value == null
                                ? Colors.red
                                : Colors.grey),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 18.0, right: 18.0),
                        child: Center(
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<Branch>(
                                isExpanded: true,
                                alignment: Alignment.center,
                                value: controller.selectedBranch.value,
                                icon: const Icon(
                                  Icons.keyboard_arrow_down,
                                  color: AppTheme.primaryColorConst,
                                  size: 30,
                                ),
                                elevation: 16,
                                style: TextStyle(
                                    fontSize: 13, color: Colors.grey[800]),
                                onChanged: (Branch? newValue) {
                                  controller.selectedBranch.value = newValue!;
                                  controller.validateBranch.value = false;
                                },
                                hint: const Text(
                                  "নির্বাচন করুণ",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.grey),
                                ),
                                items: Branch.branchList.map((e) {
                                  return DropdownMenuItem<Branch>(
                                    value: e,
                                    child: Text(e.name),
                                  );
                                }).toList()),
                          ),
                        ),
                      ));
                }),
                sizedBox,
                sizedBox,
                sizedBox,
                sizedBox,
                InkWell(
                  onTap: () async {
                    controller.validateBranch.value = true;
                    controller.validateDesignation.value = true;
                    if (_formKey.currentState!.validate()) {
                      controller.validateBranch.value = false;
                      controller.validateDesignation.value = false;
                      await controller.addOperator();
                    }
                  },
                  child: Center(
                    child: Container(
                        height: 35,
                        width: 150,
                        decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Text(
                              'অপারেটর যোগ করুন',
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        )),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
