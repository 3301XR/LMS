import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/shared/widgets/common_title_widget.dart';

import '../../../../../shared/view_models/dashboard_for_super_admin_vm.dart';
import '../../../../../shared/widgets/common_card_widget.dart';
import '../widgets/app_drawer_for_admin.dart';
import 'join_list_screen.dart';
import 'leave_list_screen.dart';
import 'pending_application_list.dart';

class DashboardForSuperAdminScreen
    extends GetView<DashboardForSuperAdminController> {
  DashboardForSuperAdminScreen({Key? key}) : super(key: key);
  final DashboardForSuperAdminController dashboardController =
      Get.put(DashboardForSuperAdminController());

  @override
  Widget build(BuildContext context) {
    var sizedBox = const SizedBox(
      height: 20,
    );
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'ড্যাশবোর্ড',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
        actions: [
          // IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          Padding(
            padding: const EdgeInsets.only(right: 20.0),
            child: SizedBox(
              width: 50,
              child: Stack(alignment: Alignment.center, children: [
                InkWell(
                    onTap: () {
                      Get.to(() => PendingApplicationListForSuperAdmin());
                    },
                    child: const Icon(Icons.notifications)),
                Positioned(
                  left: 30,
                  top: 10,
                  child: Container(
                    height: 14,
                    width: 14,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Obx(() {
                      return Center(
                        child: Text(
                          "${dashboardController.pendingApplicationList.length}",
                          style: const TextStyle(color: Colors.white),
                        ),
                      );
                    }),
                  ),
                )
              ]),
            ),
          ),
        ],
      ),
      drawer: const Drawer(
        child: AppDrawerForSuperAdmin(),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 15.0, right: 15.0),
          child: Column(
            children: [
              sizedBox,
              Obx(() {
                return CommonTitleWidget(
                  height: height * 0.1,
                  title: 'স্বাগতম ${controller.user.value?.username ?? ''} !',
                );
              }),
              sizedBox,
              CommonTitleWidget(
                height: height * 0.1,
                title: 'দাপ্তরিক',
              ),
              sizedBox,
              Obx(() {
                return CommonCardWidget(
                  icon: Icons.person_outline_sharp,
                  title: 'ছুটিতে',
                  dataInfo:
                      '${controller.dashboard.value?.applications ?? ''} জন',
                  height: height * 0.15,
                  width: width,
                  onTap: () {
                    Get.to(() => LeaveListScreen());
                  },
                );
              }),
              sizedBox,
              Obx(() {
                return CommonCardWidget(
                  icon: Icons.person_outline_sharp,
                  title: 'কর্মরত',
                  dataInfo: '${controller.dashboard.value?.join ?? ''} জন',
                  height: height * 0.15,
                  width: width,
                  onTap: () {
                    Get.to(() => JoinListScreen());
                  },
                );
              }),
              sizedBox,
              InkWell(
                child: CommonTitleWidget(
                  height: height * 0.1,
                  title: 'জমাকৃত আবেদন',
                ),
                onTap: () {
                  Get.to(() => PendingApplicationListForSuperAdmin());
                },
              ),
              sizedBox,
            ],
          ),
        ),
      ),
    );
  }
}
