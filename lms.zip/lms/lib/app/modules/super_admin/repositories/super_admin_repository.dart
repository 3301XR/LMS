import 'package:dartz/dartz.dart';
import 'package:lms/app/modules/admin/models/responses/generic_response.dart';
import 'package:lms/app/modules/admin/models/responses/operator_dashboard_response.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/models/responses/application_list_response.dart';
import 'package:lms/app/shared/errors/failures.dart';
import 'package:http/http.dart' as http;

abstract class SuperAdminRepository {
  Future<Either<Failure, ApplicationListResponse>> getTotalLeaveList();

  Future<Either<Failure, GenericResponse>> rejectApplication(int id);

  Future<Either<Failure, GenericResponse>> approveApplication(int id);

  Future<Either<Failure, DashboardResponse>> getSuperAdminDashboard();

  Future<Either<Failure, ApplicationListResponse>> getPendingApplication();
}

class SuperAdminRepositoryImpl implements SuperAdminRepository {
  final AuthRepository _authRepository;

  SuperAdminRepositoryImpl(this._authRepository);

  @override
  Future<Either<Failure, ApplicationListResponse>> getTotalLeaveList() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/emp/leave/list'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationListResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, GenericResponse>> rejectApplication(int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/admin/reject/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(
          GenericResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, GenericResponse>> approveApplication(int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/admin/approve/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(
          GenericResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, DashboardResponse>> getSuperAdminDashboard() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/admin'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    var res = await response.stream.bytesToString();
    if (response.statusCode == 200) {
      return Right(DashboardResponse.fromJson(res));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationListResponse>>
      getPendingApplication() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest('GET',
        Uri.parse('https://factanalyzer.com/api/admin/pending/application'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationListResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }
}
