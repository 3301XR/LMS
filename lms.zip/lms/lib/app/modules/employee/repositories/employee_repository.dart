import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;
import 'package:lms/app/modules/admin/models/responses/generic_response.dart';
import 'package:lms/app/modules/auth/models/requests/create_update_user_request.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/models/requests/save_application_request.dart';
import 'package:lms/app/modules/employee/models/responses/application_return_response.dart';
import 'package:lms/app/modules/employee/models/responses/employee_dashboard_response.dart';
import 'package:lms/app/modules/employee/models/responses/send_application_response.dart';
import 'package:lms/app/shared/errors/failures.dart';

import '../models/responses/application_delete_response.dart';
import '../models/responses/application_list_response.dart';
import '../models/responses/employee_profile_response.dart';

abstract class EmployeeRepository {
  Future<Either<Failure, EmployeeDashboardResponse>> getEmployeeDashboard();

  Future<Either<Failure, SendApplicationResponse>> getSendApplication();

  Future<Either<Failure, GenericResponse>> saveSendApplication(
      SaveApplicationRequest saveApplicationRequest);

  Future<Either<Failure, EmployeeApplicationDeleteResponse>>
      getApplicationDelete(int id);

  Future<Either<Failure, ApplicationListResponse>> getApplicationList(int id);

  Future<Either<Failure, ApplicationListResponse>> applicationListReturn(
      int id);

  Future<Either<Failure, ApplicationReturnResponse>> applicationDetails(int id);

  Future<Either<Failure, EmployeeProfileResponse>> getEmployeeProfiles();

  Future<Either<Failure, EmployeeProfileResponse>> getEmployeeProfileEdit(
      int id);

  Future<Either<Failure, GenericResponse>> employeeProfileUpdate(
      int id, CreateUpdateUserRequest createUpdateUserRequest);
}

class EmployeeRepositoryImpl implements EmployeeRepository {
  final AuthRepository _authRepository;

  EmployeeRepositoryImpl(this._authRepository);

  @override
  Future<Either<Failure, EmployeeDashboardResponse>>
      getEmployeeDashboard() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/employee'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(EmployeeDashboardResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, SendApplicationResponse>> getSendApplication() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/send/application'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(SendApplicationResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, GenericResponse>> saveSendApplication(
      SaveApplicationRequest saveApplicationRequest) async {
    print(saveApplicationRequest.toJson());
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest(
        'POST', Uri.parse('https://factanalyzer.com/api/application/store'));
    request.fields.addAll(saveApplicationRequest
        .toJson()
        .map((key, value) => MapEntry(key, value.toString())));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
    // print(await response.stream.bytesToString());
    if (response.statusCode == 200) {
      return Right(
          GenericResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, EmployeeApplicationDeleteResponse>>
      getApplicationDelete(int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest('GET',
        Uri.parse('https://factanalyzer.com/api/application/delete/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(EmployeeApplicationDeleteResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationListResponse>> getApplicationList(
      int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/application/list/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationListResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationListResponse>> applicationListReturn(
      int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest('GET',
        Uri.parse('https://factanalyzer.com/api/application/returnlist/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationListResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationReturnResponse>> applicationDetails(
      int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest('GET',
        Uri.parse('https://factanalyzer.com/api/application/details/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationReturnResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, EmployeeProfileResponse>> getEmployeeProfiles() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/employee/profile'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(EmployeeProfileResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, EmployeeProfileResponse>> getEmployeeProfileEdit(
      int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/employee/edit/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(EmployeeProfileResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, GenericResponse>> employeeProfileUpdate(
      int id, CreateUpdateUserRequest createUpdateUserRequest) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest(
        'POST', Uri.parse('https://factanalyzer.com/api/employee/edit/$id'));
    request.fields.addAll(createUpdateUserRequest
        .toMap()
        .map((key, value) => MapEntry(key, value.toString())));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(
          GenericResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }
}
