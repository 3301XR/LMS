import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/modules/auth/models/requests/create_update_user_request.dart';
import 'package:lms/app/modules/auth/models/responses/login_response.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/models/responses/employee_profile_response.dart';
import 'package:lms/app/modules/employee/repositories/employee_repository.dart';

class EmployeeProfileVM extends GetxController {
  final EmployeeRepository _employeeRepository = Get.find<EmployeeRepository>();
  final loginResponse = Rxn<LoginResponse>();
  final profileResponse = Rxn<EmployeeProfileResponse>();

  var nameController = TextEditingController();

  var phoneController = TextEditingController();

  var emailController = TextEditingController();

  var passwordController = TextEditingController();

  getProfileData() async {
    final AuthRepository authRepository = Get.find<AuthRepository>();
    final lr = await authRepository.getLoginResponse();
    lr.fold((l) => null, (r) async {
      loginResponse.value = r;
      final response = await _employeeRepository
          .getEmployeeProfileEdit(loginResponse.value!.data!.id!);

      response.fold((l) => null, (r) {
        profileResponse.value = r;
        populateForm();
      });
    });
  }

  populateForm() {
    // print(profileResponse.toJson());
    print(loginResponse.toJson());
    nameController.text = loginResponse.value?.data?.username ?? '';
    phoneController.text = profileResponse.value?.user?.phone ?? '';
    emailController.text = profileResponse.value?.user?.email ?? '';
    passwordController.text = loginResponse.value?.data?.password ?? '';
  }

  @override
  onInit() async {
    super.onInit();
    await getProfileData();
  }

  updateProfile() async {
    final response = await _employeeRepository.employeeProfileUpdate(
        loginResponse.value!.data!.id!,
        CreateUpdateUserRequest(
          username: nameController.text,
          phone: phoneController.text,
          email: emailController.text,
          password: passwordController.text,
        ));

    response.fold((l) => Get.snackbar("Error", l.message), (r) async {
      Get.back();
      Get.snackbar("Success", "Profile Updated Successfully");
      await getProfileData();
    });
  }
}
