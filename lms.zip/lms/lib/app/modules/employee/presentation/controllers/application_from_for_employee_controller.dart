import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/modules/auth/models/responses/login_response.dart';
import 'package:lms/app/modules/auth/models/user.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/models/requests/save_application_request.dart';
import 'package:lms/app/modules/employee/presentation/views/pages/my_application_for_employee_list.dart';
import 'package:lms/app/modules/employee/repositories/employee_repository.dart';
import 'package:lms/app/shared/widgets/snackbars.dart';

class ApplicationFromForEmployeeController extends GetxController {
  final AdminRepository _adminRepository = Get.find<AdminRepository>();
  final AuthRepository _authRepository = Get.find<AuthRepository>();

  final EmployeeRepository _employeeRepository = Get.find<EmployeeRepository>();
  final selectedOparetor = Rxn<User>();
  final selectedLeaveReason = Rxn<String>();

  var fromDateController = TextEditingController();

  var toDateController = TextEditingController();

  final operatorList = <User>[].obs;
  final reasonList = <String>['শারীরিক অসুস্থতা', 'পারিবারিক', 'অন্যান্য'];

  var locationController = TextEditingController();

  var otherReasonController = TextEditingController();

  final loginResponse = Rxn<LoginResponse>();
  final employee = Rxn<User>();

  void onSave() {}

  onConfirm() async {
    var lr = await _authRepository.getLoginResponse();

    lr.fold((l) => null, (r) => loginResponse.value = r);

    //TODO : fix according to the backend fix
    // final employeeResponse =
    //     await _adminRepository.getEmployeeDetails(user.value!.id!);
    // employeeResponse.fold((l) => null, (r) {
    //   return employee.value = r.user;
    // });

    final response =
        await _employeeRepository.saveSendApplication(SaveApplicationRequest(
      adminId: selectedOparetor.value?.id.toString(),
      // department: loginResponse.value?.department,
      department: "department",
      email: loginResponse.value?.data?.email,
      employeeId: loginResponse.value?.data?.id.toString(),
      start: fromDateController.text,
      stay: locationController.text,
      reason: otherReasonController.text.isNotEmpty
          ? otherReasonController.text
          : selectedLeaveReason.value,
      end: toDateController.text,
      name: loginResponse.value!.data?.username,
      totalDays: (DateTime.parse(toDateController.text)
                  .difference(DateTime.parse(fromDateController.text))
                  .inDays +
              1)
          .toString(),
    ));
    print(response);
    response.fold((l) => MySnackBars.showErrorSnackBar(l.message), (r) {
      print(r.toJson());
      Get.back();
      if (r.message?.contains('উক্ত') ?? false) {
        MySnackBars.showErrorSnackBar(r.message!);
      } else {
        Get.off(() => MyApplicationForEmployeeList());
        MySnackBars.showSuccessSnackBar(r.message!);
      }
    });
  }

  getOperatorList() async {
    final response = await _employeeRepository.getSendApplication();

    response.fold((l) => null, (r) => operatorList.assignAll(r.user!));
  }

  @override
  onInit() async {
    super.onInit();
    await getOperatorList();
  }

  void onReset() {
    fromDateController.text = '';
    toDateController.text = '';
    locationController.text = '';
    otherReasonController.text = '';
    selectedOparetor.value = null;
    selectedLeaveReason.value = null;
  }
}
