import 'package:get/get.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/repositories/employee_repository.dart';
import 'package:lms/app/shared/values/filter_data.dart';
import '../../../auth/models/user.dart';
import '../../models/application.dart';

class ApplicationController extends GetxController {
  final isHealthExpanded = <bool>[].obs;
  final EmployeeRepository _employeeRepository = Get.find();
  final allApplicationList = <Application>[].obs;
  final applicationList = <Application>[].obs;
  final AuthRepository _authRepository = Get.find();
  final user = Rxn<User>();

  getApplicationList() async {
    final loginData = await _authRepository.getLoginResponse();
    loginData.fold((l) => null, (r) => user.value = r.data);
    final response =
        await _employeeRepository.getApplicationList(user.value!.id!);
    response.fold((l) => null, (r) {
      allApplicationList.assignAll(r.applications!.reversed);
      applicationList.assignAll(r.applications!.reversed);
    });
  }

  @override
  onInit() async {
    super.onInit();
    await getApplicationList();
  }

  onDeleted(int id) async {
    final response = await _employeeRepository.getApplicationDelete(id);

    response.fold((l) => null, (r) async => await getApplicationList());
  }

  void onSearch(String v) {
    if (selectedFilter.value?.key == "") {
      applicationList.assignAll(allApplicationList
          .where((p0) => p0.toJson().toLowerCase().contains(v.toLowerCase())));
    } else {
      applicationList.assignAll(allApplicationList.where((p0) =>
          p0.approve == selectedFilter.value?.key &&
          p0.toJson().toLowerCase().contains(v.toLowerCase())));
    }
  }

  var selectedFilter = Rxn<ApplicationStatus>();

  void onFilter(ApplicationStatus? v) {
    if (v?.key == "") {
      applicationList.assignAll(allApplicationList);
    } else {
      applicationList
          .assignAll(allApplicationList.where((p0) => p0.approve == v!.key));
    }
  }
}
