import 'package:get/get.dart';
import 'package:lms/app/modules/auth/models/user.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/models/application.dart';
import 'package:lms/app/modules/employee/models/responses/employee_dashboard_response.dart';
import 'package:lms/app/modules/employee/repositories/employee_repository.dart';

class EmployeeDashboardController extends GetxController {
  final EmployeeRepository _employeeRepository = Get.find();

  final dashboardResponse = Rxn<EmployeeDashboardResponse>();
  final applicationList = <Application>[].obs;
  final AuthRepository _authRepository = Get.find();
  final user = Rxn<User>();

  getApplicationList() async {
    final loginData = await _authRepository.getLoginResponse();
    loginData.fold((l) => null, (r) => user.value = r.data);
    final response =
        await _employeeRepository.getApplicationList(user.value!.id!);
    response.fold((l) => null,
        (r) => applicationList.assignAll(r.applications!.reversed));
  }

  getDashboard() async {
    final response = await _employeeRepository.getEmployeeDashboard();

    response.fold((l) => null, (r) {
      return dashboardResponse.value = r;
    });
  }

  @override
  onInit() async {
    super.onInit();
    await getDashboard();
  }
}
