import 'package:get/get.dart';
import 'package:lms/app/modules/auth/presentation/views/login_screen.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';

import '../../../auth/models/user.dart';

class UserDrawerController extends GetxController {
  final isActiveApplication = false.obs;
  final AuthRepository _authRepository = Get.find();

  var isActiveAdmin = false.obs;

  var isEmployeeActive = false.obs;
  final user = Rxn<User>();

  onGetUserDate() async {
    final response = await _authRepository.getLoginResponse();
    response.fold((l) => null, (r) => user.value = r.data);
  }

  // var activeApplication;
  onLogout() async {
    final response = await _authRepository.logout();
    response.fold((l) => Get.offAll(() => LoginScreen()),
        (r) => Get.offAll(() => LoginScreen()));
  }

  onInit() async {
    super.onInit();
    await onGetUserDate();
  }
}
