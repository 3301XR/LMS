import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:lms/app/modules/admin/presentation/views/widgets/auth_field_widget.dart';
import 'package:lms/app/modules/auth/models/user.dart';

import '../../../../../shared/values/colors.dart';
import '../../controllers/application_from_for_employee_controller.dart';

class ApplicationFromForEmployeeScreen extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();

  ApplicationFromForEmployeeScreen({Key? key}) : super(key: key) {
    controller = Get.put(ApplicationFromForEmployeeController());
  }

  late final ApplicationFromForEmployeeController controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('আবেদনপত্র'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 15.0, right: 15.0, top: 15),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ছুটি অনুমোদনকারী:',
                  style: TextStyle(
                    color: Color(0xff2E3A59),
                  ),
                ),
                Obx(() {
                  return Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(5.0),
                      border: Border.all(color: Colors.grey),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 18.0, right: 18.0),
                      child: Center(
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<User>(
                              isExpanded: true,
                              alignment: Alignment.center,
                              value: controller.selectedOparetor.value,
                              icon: const Icon(
                                Icons.keyboard_arrow_down,
                                color: AppTheme.primaryColorConst,
                                size: 30,
                              ),
                              elevation: 16,
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey[800]),
                              onChanged: (User? newValue) {
                                controller.selectedOparetor.value = newValue!;
                              },
                              hint: const Text(
                                "অপারেটর নির্বাচন করুন",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.grey),
                              ),
                              items: controller.operatorList.map((e) {
                                return DropdownMenuItem<User>(
                                  value: e,
                                  child: Text(e.username!),
                                );
                              }).toList()),
                        ),
                      ),
                    ),
                  );
                }),
                const SizedBox(
                  height: 20,
                ),
                Obx(() {
                  return controller.selectedLeaveReason.value == "অন্যান্য"
                      ? MyAuthFormField(
                          maxLines: 3,
                          controller: controller.otherReasonController,
                          labelText: 'অন্যান্য কারণ',
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'অন্যান্য কারণ দিন';
                            }
                            return null;
                          },
                        )
                      : Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'ছুটি কারণ:',
                              style: TextStyle(
                                color: Color(0xff2E3A59),
                              ),
                            ),
                            Obx(() {
                              return Container(
                                height: 40,
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(5.0),
                                  border: Border.all(color: Colors.grey),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 18.0, right: 18.0),
                                  child: Center(
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton<String>(
                                          isExpanded: true,
                                          alignment: Alignment.center,
                                          value: controller
                                              .selectedLeaveReason.value,
                                          icon: const Icon(
                                            Icons.keyboard_arrow_down,
                                            color: AppTheme.primaryColorConst,
                                            size: 30,
                                          ),
                                          elevation: 16,
                                          style: TextStyle(
                                              fontSize: 13,
                                              color: Colors.grey[800]),
                                          onChanged: (String? newValue) {
                                            controller.selectedLeaveReason
                                                .value = newValue!;
                                          },
                                          hint: const Text(
                                            "ছুটির কারণ নির্বাচন করুন",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                fontSize: 13,
                                                fontWeight: FontWeight.w600,
                                                color: Colors.grey),
                                          ),
                                          items: controller.reasonList.map((e) {
                                            return DropdownMenuItem<String>(
                                              value: e,
                                              child: Text(e),
                                            );
                                          }).toList()),
                                    ),
                                  ),
                                ),
                              );
                            }),
                          ],
                        );
                }),
                const SizedBox(
                  height: 20,
                ),
                MyAuthFormField(
                  controller: controller.fromDateController,
                  readOnly: true,
                  hinText: 'mm/dd/yy',
                  labelText: 'হতে:',
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'তারিখ দিন';
                    }
                    return null;
                  },
                  onTap: () {
                    showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900),
                      lastDate: DateTime(2050),
                    ).then((value) async {
                      if (value != null) {
                        controller.fromDateController.text =
                            DateFormat('yyyy-MM-dd').format(value);
                      }
                    });
                  },
                ),

                const SizedBox(
                  height: 20,
                ),
                MyAuthFormField(
                  readOnly: true,
                  controller: controller.toDateController,
                  hinText: 'mm/dd/yy',
                  labelText: 'ছুটির মেয়াদকাল:',
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'তারিখ দিন';
                    }
                    return null;
                  },
                  onTap: () {
                    showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900),
                      lastDate: DateTime(2050),
                    ).then((value) async {
                      if (value != null) {
                        controller.toDateController.text =
                            DateFormat('yyyy-MM-dd').format(value);
                      }
                    });
                  },
                ),
                const SizedBox(
                  height: 20,
                ),

                MyAuthFormField(
                  hinText: 'ছুটিকালীন অবস্থান',
                  labelText: 'ছুটিকালীন অবস্থান : ',
                  controller: controller.locationController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'অবস্থান দিন';
                    }
                    return null;
                  },
                ),
                // MyAuthFormField(),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        controller.onReset();
                      },
                      child: Container(
                          height: 40,
                          width: MediaQuery.of(context).size.width * 0.3,
                          decoration: BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(10)),
                          child: const Center(
                            child: Text(
                              'পুনঃস্থাপন',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600),
                            ),
                          )),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    InkWell(
                      onTap: () {
                        if (_formKey.currentState!.validate()) {
                          _confirmationDialog(context);
                        }
                      },
                      child: Container(
                          height: 40,
                          width: MediaQuery.of(context).size.width * 0.3,
                          decoration: BoxDecoration(
                              color: Colors.green,
                              borderRadius: BorderRadius.circular(10)),
                          child: const Center(
                            child: Text(
                              'দাখিল',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600),
                            ),
                          )),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  _confirmationDialog(BuildContext context) async {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, StateSetter setState) {
          return AlertDialog(
            content: SingleChildScrollView(
                child: SizedBox(
              height: height * 0.5,
              width: width,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: const [
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            'জমা নিশ্চিত করুন',
                            style: TextStyle(
                                fontWeight: FontWeight.w500, fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        'আপনি কি নিশ্চিত যে আপনি নিম্নলিখিত বিবরণ জমা দিতে চান?',
                        style: TextStyle(
                            fontWeight: FontWeight.w500, fontSize: 13),
                      ),
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Obx(() {
                            return Text(
                              'অনুমোদনকারী: ${controller.selectedOparetor.value?.username ?? ''}',
                              style: TextStyle(
                                  fontWeight: FontWeight.w600, fontSize: 13),
                            );
                          }),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            'কারণ: ${controller.selectedLeaveReason.value ?? ''}',
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'মেয়াদকাল: ${controller.fromDateController.text}',
                              style: TextStyle(
                                  fontWeight: FontWeight.w600, fontSize: 13),
                            ),
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.all(8.0),
                            child: SizedBox(
                              width: 100,
                              child: Text(
                                controller.toDateController.text,
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 13),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            'ছুটিকালীন অবস্থান: ${controller.locationController.text}',
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            'আবেদকৃত ছুটি',
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 13),
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.all(8.0),
                            child: SizedBox(
                              width: 100,
                              child: Text(
                                '${DateTime.parse(controller.toDateController.text).difference(DateTime.parse(controller.fromDateController.text)).inDays + 1} দিন',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 13),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: const Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Text(
                                'ফেরত',
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold),
                              ),
                            )),
                        InkWell(
                          onTap: () async {
                            await controller.onConfirm();
                          },
                          child: const Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'দাখিল',
                              style: TextStyle(
                                  color: AppTheme.primaryColorConst,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            )),
          );
        });
      },
    );
  }
}
