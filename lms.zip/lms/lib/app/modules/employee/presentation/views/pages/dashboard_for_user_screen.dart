import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/modules/employee/presentation/views/pages/application_from_for_employee_screen.dart';
import 'package:lms/app/modules/employee/presentation/views/widgets/app_drawer_for_user.dart';
import 'package:lms/app/shared/widgets/common_title_widget.dart';

import '../../../../../shared/widgets/common_card_widget.dart';
import '../../controllers/employee_dashboard_controller.dart';
import 'my_application_for_employee_list.dart';

class DashboardForUserScreen extends StatelessWidget {
  DashboardForUserScreen({Key? key}) : super(key: key);
  final EmployeeDashboardController controller =
      Get.put(EmployeeDashboardController());

  @override
  Widget build(BuildContext context) {
    var sizedBox = const SizedBox(
      height: 20,
    );
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'ড্যাশবোর্ড',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
        actions: [
          // IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          Padding(
            padding: const EdgeInsets.only(right: 20.0),
            child: SizedBox(
              width: 50,
              child: Stack(alignment: Alignment.center, children: [
                InkWell(
                    onTap: () {
                      Get.to(() => MyApplicationForEmployeeList());
                    },
                    child: const Icon(Icons.notifications)),
                Positioned(
                  left: 30,
                  top: 10,
                  child: Container(
                    height: 14,
                    width: 14,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Obx(() {
                      return Center(
                        child: Text(
                          "${controller.applicationList.length}",
                          style: const TextStyle(color: Colors.white),
                        ),
                      );
                    }),
                  ),
                )
              ]),
            ),
          ),
        ],
      ),
      drawer: const Drawer(
        child: AppDrawerForUser(),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 15.0, right: 15.0),
          child: Column(
            children: [
              sizedBox,
              Obx(() {
                return CommonTitleWidget(
                  height: height * 0.1,
                  title:
                      'স্বাগতম ${controller.dashboardResponse.value?.user?.username ?? ''} !',
                );
              }),
              sizedBox,
              Obx(() {
                return CommonCardWidget(
                  icon: Icons.person_outline_sharp,
                  title: 'ভোগকৃত ছুটি',
                  dataInfo:
                      '${controller.dashboardResponse.value?.leaveTaken ?? 0} দিন',
                  height: height * 0.15,
                  width: width,
                );
              }),
              sizedBox,
              Obx(() {
                return CommonCardWidget(
                  icon: Icons.person_outline_sharp,
                  title: 'অবশিষ্ট ছুটি',
                  dataInfo:
                      '${controller.dashboardResponse.value?.remaingLeave ?? 0} দিন',
                  height: height * 0.15,
                  width: width,
                );
              }),
              sizedBox,
              InkWell(
                onTap: () {
                  Get.to(() => MyApplicationForEmployeeList());
                },
                child: CommonTitleWidget(
                  height: height * 0.1,
                  title: 'আবেদনের হিসাব',
                ),
              ),
              sizedBox,
              InkWell(
                onTap: () {
                  Get.to(() => ApplicationFromForEmployeeScreen());
                },
                child: CommonTitleWidget(
                  height: height * 0.1,
                  title: 'আবেদন',
                ),
              ),
              sizedBox,
            ],
          ),
        ),
      ),
    );
  }
}
