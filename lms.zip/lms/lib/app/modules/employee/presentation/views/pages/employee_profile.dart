import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controllers/employee_profile_vm.dart';
import 'edit_profile_for_employee_screen.dart';

class EmployeeProfileScreen extends StatelessWidget {
  EmployeeProfileScreen({Key? key}) : super(key: key) {
    controller = Get.put(EmployeeProfileVM());
  }

  late final EmployeeProfileVM controller;

  @override
  Widget build(BuildContext context) {
    var sizedBox = const SizedBox(
      height: 20,
    );
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'প্রোফাইল',
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            sizedBox,
            Container(
                decoration: const BoxDecoration(color: Color(0XFFD4DBF9)),
                height: 80,
                width: MediaQuery.of(context).size.width,
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text('প্রোফাইলে স্বাগতম!'),
                          Obx(() {
                            return Text(controller
                                    .loginResponse.value?.data?.username ??
                                '');
                          }),
                        ],
                      ),
                      Image.asset(
                        'assets/profile-img.png',
                        fit: BoxFit.cover,
                      ),
                    ],
                  ),
                )),
            sizedBox,
            Padding(
              padding: const EdgeInsets.only(left: 15.0, right: 15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'কর্মচারী',
                        style: TextStyle(fontSize: 18),
                      ),
                      Obx(() {
                        return Text(
                            controller.profileResponse.value?.user?.isActive ==
                                    "1"
                                ? 'সক্রিয়'
                                : 'নিষ্ক্রিয়');
                      }),
                    ],
                  ),
                  InkWell(
                    onTap: () {
                      Get.to(() => EditProfileForEmployeeScreen());
                    },
                    child: Container(
                        height: 35,
                        width: 150,
                        decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Text(
                              'হালনাগাত করুণ',
                              style: TextStyle(color: Colors.white),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Icon(
                              Icons.arrow_forward,
                              size: 20,
                              color: Colors.white,
                            )
                          ],
                        )),
                  )
                ],
              ),
            ),
            sizedBox,
            Padding(
              padding: const EdgeInsets.only(left: 15.0, right: 15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Obx(() {
                        return Text(
                          'পদবী: ${controller.profileResponse.value?.user?.department ?? ''}',
                          style: TextStyle(fontSize: 15),
                        );
                      }),
                      Obx(() {
                        return Text(
                          'ইমেইল: ${controller.profileResponse.value?.user?.email ?? ''}',
                          style: const TextStyle(fontSize: 15),
                        );
                      }),
                    ],
                  ),
                ],
              ),
            ),
            sizedBox,
            Padding(
              padding: const EdgeInsets.only(left: 15.0, right: 15.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'ব্যক্তিগত তথ্য',
                        style: TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.2,
                        child: const Text(
                          'নাম:',
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                      SizedBox(
                        width: width * 0.6,
                        child: Obx(() {
                          return Text(
                            controller.loginResponse.value?.data?.username ??
                                '',
                            style: TextStyle(fontSize: 15),
                          );
                        }),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.2,
                        child: const Text(
                          'মুঠোফোন :',
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                      SizedBox(
                        width: width * 0.6,
                        child: Obx(() {
                          return Text(
                            controller.profileResponse.value?.user?.phone ?? '',
                            style: TextStyle(fontSize: 15),
                          );
                        }),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.2,
                        child: const Text(
                          'ইমেইল  :',
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                      SizedBox(
                        width: width * 0.6,
                        child: Obx(() {
                          return Text(
                            controller.profileResponse.value?.user?.email ?? '',
                            style: TextStyle(fontSize: 15),
                          );
                        }),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.2,
                        child: const Text(
                          'শাখা   :',
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                      SizedBox(
                        width: width * 0.6,
                        child: Text(
                          controller.profileResponse.value?.user?.branch ?? '',
                          style: TextStyle(fontSize: 15),
                        ),
                        // child: Obx(() {
                        //   return Text(
                        //     // controller.loginResponse.value?.branch ?? '',
                        //     "",
                        //     style: TextStyle(fontSize: 15),
                        //   );
                        // }),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
