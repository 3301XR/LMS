import 'package:flutter/material.dart';
import 'package:lms/app/modules/employee/models/application.dart';

class MyApplicationForEmployeeDetailsScreen extends StatelessWidget {
  const MyApplicationForEmployeeDetailsScreen({
    Key? key,
    required this.application,
  }) : super(key: key);
  final Application application;

  @override
  Widget build(BuildContext context) {
    var sizedBox = const SizedBox(
      height: 20,
    );
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        // backgroundColor: Colors.white,
        // automaticallyImplyLeading: false,
        title: const Text(
          'বিস্তারিত তথ্য',
          // style: TextStyle(color: AppTheme.primaryFontColo),
        ),
        // leading: IconButton(
        //     onPressed: () {
        //       Get.back();
        //     },
        //     icon: Icon(
        //       Icons.arrow_back_ios_rounded,
        //       color: Colors.grey[700],
        //     )),
        elevation: 0,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          sizedBox,
          Padding(
            padding: const EdgeInsets.only(left: 15.0, right: 15.0),
            child: Column(
              children: [
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'আবেদনের তারিখ:',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        application.createdAt ?? "",
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'ছুটির মেয়াদকাল শুরু: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        application.start ?? "",
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'ছুটির মেয়াদকাল শেষ: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        application.end ?? "",
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'আবেদনকৃত ছুটি: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        '${application.totalDays} দিন',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'অনুমোদিত ছুটি: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        '${application.totalDays} দিন',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'অবস্থান: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        application.stay ?? "",
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'কারন: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        application.reason ?? "",
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'মন্তব্য: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        application.comment ?? "",
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      child: Text(
                        'বর্তমান অবস্থা: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    Flexible(
                      child: application.approve == "1"
                          ? const Text(
                              ' অনুমোদিত',
                              overflow: TextOverflow.ellipsis,
                              style:
                                  TextStyle(fontSize: 18, color: Colors.green),
                            )
                          : application.approve == "0"
                              ? const Text(
                                  ' প্রত্যাখ্যাত',
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 18, color: Colors.red),
                                )
                              : Text(
                                  ' অপেক্ষমাণ..',
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 18, color: Colors.green[300]),
                                ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
