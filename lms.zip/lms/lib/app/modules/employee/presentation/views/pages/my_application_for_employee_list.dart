import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/shared/values/filter_data.dart';

import '../../../../employee/presentation/controllers/application_controller.dart';
import 'myApplication_details_for_employee_screen.dart';

class MyApplicationForEmployeeList extends StatelessWidget {
  MyApplicationForEmployeeList({Key? key}) : super(key: key) {
    controller = Get.put(ApplicationController());
  }

  late final ApplicationController controller;

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text('আমার আবেদন তালিকা'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      onChanged: (v) {
                        controller.onSearch(v);
                      },
                      decoration: InputDecoration(
                          contentPadding: const EdgeInsets.only(left: 20),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5),
                              borderSide: const BorderSide(
                                color: Colors.grey,
                              )),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5),
                              borderSide: const BorderSide(
                                color: Colors.grey,
                              )),
                          hintText: "Search"),
                    ),
                  ),
                ),
                Obx(() {
                  return DropdownButton<ApplicationStatus>(
                      hint: const Text('Filter'),
                      value: controller.selectedFilter.value,
                      items: ApplicationStatus.filterList
                          .map((e) => DropdownMenuItem<ApplicationStatus>(
                              value: e, child: Text(e.name)))
                          .toList(),
                      onChanged: (v) {
                        controller.selectedFilter.value = v;
                        controller.onFilter(v);
                      });
                })
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10.0, right: 10.0),
              child: Obx(() {
                return ListView.builder(
                  shrinkWrap: true,
                  itemCount: controller.applicationList.length,
                  itemBuilder: (context, index) {
                    controller.isHealthExpanded.add(false);
                    var item = controller.applicationList[index];

                    return Column(
                      children: [
                        Container(
                          margin: const EdgeInsets.all(5),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.5),
                                spreadRadius: 1,
                                blurRadius: 1,
                                offset: const Offset(
                                    1, 1), // changes position of shadow
                              ),
                            ],
                            color: Colors.white,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              InkWell(
                                onTap: () {
                                  controller.isHealthExpanded[index] =
                                      !controller.isHealthExpanded[index];
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(5),
                                  child: Container(
                                      decoration: BoxDecoration(
                                          color: Colors.blue,
                                          borderRadius:
                                              BorderRadius.circular(25)),
                                      child: const Icon(
                                        Icons.add,
                                        color: Colors.white,
                                      )),
                                ),
                              ),
                              SizedBox(
                                  width: width * 0.64,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        'ছুটির মেয়াদকাল শুরু ',
                                        style: TextStyle(
                                            fontWeight: FontWeight.w600,
                                            fontSize: 12),
                                      ),
                                      Text(
                                        item.start ?? '',
                                        style: const TextStyle(fontSize: 12),
                                      ),
                                    ],
                                  ))
                            ],
                          ),
                        ),
                        Obx(() => controller.isHealthExpanded[index]
                            ? Container(
                                width: width,
                                margin: const EdgeInsets.only(
                                    top: 10, bottom: 10, left: 10, right: 10),
                                decoration:
                                    const BoxDecoration(color: Colors.white),
                                child: Column(
                                  children: [
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        const Text(
                                          'ছুটির মেয়াদকাল শেষ ',
                                          style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 12),
                                        ),
                                        Flexible(
                                          child: Text(
                                            item.end ?? '',
                                            overflow: TextOverflow.ellipsis,
                                            style:
                                                const TextStyle(fontSize: 12),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        const Text(
                                          'আবেদনকৃত ছুটি ',
                                          style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 12),
                                        ),
                                        Flexible(
                                          child: Text(
                                            ' ${item.total ?? ""} দিন',
                                            overflow: TextOverflow.ellipsis,
                                            style:
                                                const TextStyle(fontSize: 12),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        const Text(
                                          'অনুমোদিত ছুটি ',
                                          style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 12),
                                        ),
                                        Flexible(
                                          child: Text(
                                            ' ${item.totalDays ?? ''} দিন',
                                            overflow: TextOverflow.ellipsis,
                                            style:
                                                const TextStyle(fontSize: 12),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        const Text(
                                          'বর্তমান অবস্থা ',
                                          style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 12),
                                        ),
                                        Flexible(
                                          child: item.approve == "1"
                                              ? const Text(
                                                  ' অনুমোদিত',
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                      fontSize: 18,
                                                      color: Colors.green),
                                                )
                                              : item.approve == "0"
                                                  ? const Text(
                                                      ' প্রত্যাখ্যাত',
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: TextStyle(
                                                          fontSize: 18,
                                                          color: Colors.red),
                                                    )
                                                  : Text(
                                                      ' অপেক্ষমাণ..',
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: TextStyle(
                                                          fontSize: 18,
                                                          color: Colors
                                                              .green[300]),
                                                    ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        const Text(
                                          'বিস্তারিত',
                                          style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 12),
                                        ),
                                        InkWell(
                                          onTap: () {
                                            Get.to(() =>
                                                MyApplicationForEmployeeDetailsScreen(
                                                  application: item,
                                                ));
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Container(
                                              height: 35,
                                              width: 35,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(5),
                                                color: Colors.blue,
                                              ),
                                              child: const Icon(
                                                Icons.remove_red_eye,
                                                size: 20,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                        ),
                                        item.approve == null
                                            ? InkWell(
                                                onTap: () {
                                                  showDeletePopup(
                                                      context, item.id!);
                                                },
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Container(
                                                    height: 35,
                                                    width: 35,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5),
                                                      color: Colors.red,
                                                    ),
                                                    child: const Icon(
                                                      Icons.delete,
                                                      size: 20,
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                ),
                                              )
                                            : Container(),
                                      ],
                                    ),
                                  ],
                                ))
                            : const SizedBox())
                      ],
                    );
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  showDeletePopup(BuildContext context, int id) {
    // set up the button
    Widget okButton = Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        InkWell(
          onTap: () {
            Get.back();
          },
          child: const Padding(
            padding: EdgeInsets.all(15),
            child: Text('বাতিল'),
          ),
        ),
        InkWell(
          onTap: () async {
            await controller.onDeleted(id);
            Get.back();
          },
          child: const Padding(
            padding: EdgeInsets.all(15),
            child: Text('মুছে ফেলুন'),
          ),
        )
      ],
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("আপনি মুছে ফেলতে চান"),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
