import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../../../../../shared/values/colors.dart';
import '../../controllers/user_drawer_controller.dart';
import '../pages/employee_profile.dart';
import '../pages/my_application_for_employee_list.dart';
import 'app_drawer_for_user.dart';

class UserDrawerWidget extends GetView<UserDrawerController> {
  UserDrawerWidget({Key? key}) : super(key: key);
  final UserDrawerController appDrawerVM = Get.put(UserDrawerController());

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: 80,
          color: AppTheme.primaryColor,
          child: Padding(
            padding: const EdgeInsets.only(left: 15.0, right: 15.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Obx(() {
                      return Text(
                        controller.user.value?.username ?? "",
                        style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w600),
                      );
                    }),
                    Obx(() {
                      return Text(
                        controller.user.value?.email ?? "",
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                            fontSize: 10),
                      );
                    }),
                  ],
                ),
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.clear,
                      color: Colors.white,
                    ))
              ],
            ),
          ),
        ),
        DrawerListWidget(
          label: 'ড্যাশবোর্ড',
          image: 'assets/dashboard_icon.png',
          color: AppTheme.primaryColor,
          onTap: () {
            Navigator.pop(context);
          },
        ),
        const Divider(
          height: 1,
        ),
        DrawerListWidget(
          label: 'প্রোফাইল',
          image: 'assets/dashboard_icon.png',
          color: AppTheme.primaryColor,
          onTap: () {
            Get.to(() => EmployeeProfileScreen());
          },
        ),
        const Divider(
          height: 1,
        ),
        Obx(() {
          return DrawerListWidget(
            label: 'আবেদন',
            image: 'assets/center_icon.png',
            colorLabel: controller.isActiveApplication.value == true
                ? AppTheme.primaryColor
                : Colors.black,
            color: AppTheme.primaryColor,
            iconTrailing: controller.isActiveApplication.value == true
                ? Icons.keyboard_arrow_up_rounded
                : Icons.keyboard_arrow_down_rounded,
            onTap: () {
              controller.isActiveApplication.value =
                  !controller.isActiveApplication.value;
            },
          );
        }),
        Obx(
          () => controller.isActiveApplication.value == false
              ? const SizedBox()
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(
                      height: 10,
                    ),
                    InkWell(
                      onTap: () {
                        // Get.to(AllApplicationList());
                        Get.to(() => MyApplicationForEmployeeList());
                      },
                      child: SizedBox(
                        height: 40,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(),
                            Row(
                              children: [
                                Container(
                                  height: 10,
                                  width: 10,
                                  decoration: BoxDecoration(
                                      color: AppTheme.primaryColor,
                                      borderRadius: BorderRadius.circular(25)),
                                ),
                                const SizedBox(
                                  width: 20,
                                ),
                                SizedBox(
                                    width:
                                        MediaQuery.of(context).size.width * 0.4,
                                    child: const Text(
                                      'আবেদনকৃত তালিকা',
                                    )),
                              ],
                            ),
                            const SizedBox(),
                            const SizedBox(),
                          ],
                        ),
                      ),
                    ),
                    // const SizedBox(height: 10,),
                    const SizedBox(
                      height: 10,
                    ),
                  ],
                ),
        ),
        const Divider(
          height: 1,
        ),
        DrawerListWidget(
          label: 'লগ আউট',
          image: 'assets/dashboard_icon.png',
          color: AppTheme.primaryColor,
          onTap: () {
            controller.onLogout();
          },
        ),
        const Divider(
          height: 1,
        ),
      ],
    );
  }
}
