import 'dart:convert';

class EmployeeOrOperator {
  EmployeeOrOperator({
    this.id,
    this.firstName,
    this.branch,
    this.phone,
    this.email,
    this.department,
    this.password,
    this.role,
    this.image,
    this.isActive,
    this.createdAt,
    this.updatedAt,
  });

  int? id;
  String? firstName;
  String? branch;
  String? phone;
  String? email;
  String? department;
  String? password;
  String? role;
  dynamic image;
  String? isActive;
  dynamic createdAt;
  dynamic updatedAt;

  factory EmployeeOrOperator.fromJson(String str) =>
      EmployeeOrOperator.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory EmployeeOrOperator.fromMap(Map<String, dynamic> json) =>
      EmployeeOrOperator(
        id: json["id"],
        firstName: json["first_name"],
        branch: json["branch"],
        phone: json["phone"],
        email: json["email"],
        department: json["department"],
        password: json["password"],
        role: json["role"],
        image: json["image"],
        isActive: json["is_active"],
        createdAt: json["created_at"],
        updatedAt: json["updated_at"],
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "first_name": firstName,
        "branch": branch,
        "phone": phone,
        "email": email,
        "department": department,
        "password": password,
        "role": role,
        "image": image,
        "is_active": isActive,
        "created_at": createdAt,
        "updated_at": updatedAt,
      };
}
