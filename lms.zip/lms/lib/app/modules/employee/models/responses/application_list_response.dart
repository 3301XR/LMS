// To parse this JSON data, do
//
//     final employeeApplicationListResponse = employeeApplicationListResponseFromJson(jsonString);

import 'dart:convert';

import '../application.dart';

class ApplicationListResponse {
  ApplicationListResponse({
    this.applications,
  });

  List<Application>? applications;

  factory ApplicationListResponse.fromJson(String str) {
    print(str);
    return ApplicationListResponse.fromMap(json.decode(str));
  }

  String toJson() => json.encode(toMap());

  factory ApplicationListResponse.fromMap(Map<String, dynamic> json) =>
      ApplicationListResponse(
        applications: json["applications"] == null
            ? null
            : List<Application>.from(
                json["applications"].map((x) => Application.fromMap(x))),
      );

  Map<String, dynamic> toMap() => {
        "applications": applications == null
            ? null
            : List<dynamic>.from(applications!.map((x) => x.toMap())),
      };
}
