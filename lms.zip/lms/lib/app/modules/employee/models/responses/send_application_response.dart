// To parse this JSON data, do
//
//     final sendApplicationResponse = sendApplicationResponseFromJson(jsonString);

import 'dart:convert';

import 'package:lms/app/modules/auth/models/user.dart';

class SendApplicationResponse {
  SendApplicationResponse(
      {this.message, this.user, this.dept, this.superAdmin});

  String? message;
  List<User>? user;
  List<User>? superAdmin;
  User? dept;

  factory SendApplicationResponse.fromJson(String str) =>
      SendApplicationResponse.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory SendApplicationResponse.fromMap(Map<String, dynamic> json) =>
      SendApplicationResponse(
        message: json["message"],
        user: json["user"] == null
            ? null
            : List<User>.from(json["user"].map((x) => User.fromMap(x))),
        superAdmin: json["superadmin"] == null
            ? null
            : List<User>.from(json["superadmin"].map((x) => User.fromMap(x))),
        dept: json["dept"] == null ? null : User.fromMap(json["dept"]),
      );

  Map<String, dynamic> toMap() => {
        "message": message,
        "user": user == null
            ? null
            : List<dynamic>.from(user!.map((x) => x.toJson())),
        "superadmin": superAdmin == null
            ? null
            : List<dynamic>.from(superAdmin!.map((x) => x.toJson())),
        "dept": dept?.toJson(),
      };
}
