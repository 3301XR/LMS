// To parse this JSON data, do
//
//     final employeeDashboardResponse = employeeDashboardResponseFromMap(jsonString);

import 'dart:convert';

import 'package:lms/app/modules/auth/models/user.dart';

class EmployeeDashboardResponse {
  EmployeeDashboardResponse({
    this.message,
    this.user,
    this.days,
    this.leaveTaken,
    this.remaingLeave,
  });

  String? message;
  User? user;
  dynamic? days;
  dynamic? leaveTaken;
  dynamic? remaingLeave;

  factory EmployeeDashboardResponse.fromJson(String str) =>
      EmployeeDashboardResponse.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory EmployeeDashboardResponse.fromMap(Map<String, dynamic> json) =>
      EmployeeDashboardResponse(
        message: json["message"],
        user: json["user"] == null ? null : User.fromMap(json["user"]),
        days: json["days"],
        leaveTaken: json["leaveTaken"],
        remaingLeave: json["remaingLeave"],
      );

  Map<String, dynamic> toMap() => {
        "message": message,
        "user": user?.toMap(),
        "days": days,
        "leaveTaken": leaveTaken,
        "remaingLeave": remaingLeave,
      };
}
