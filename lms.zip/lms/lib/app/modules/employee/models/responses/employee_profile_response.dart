// To parse this JSON data, do
//
//     final employeeProfiletResponse = employeeProfiletResponseFromJson(jsonString);

import 'dart:convert';

import 'package:lms/app/modules/employee/models/employee_or_operator.dart';

import '../../../auth/models/user.dart';

class EmployeeProfileResponse {
  EmployeeProfileResponse({
    this.user,
  });

  EmployeeOrOperator? user;

  factory EmployeeProfileResponse.fromRawJson(String str) =>
      EmployeeProfileResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory EmployeeProfileResponse.fromJson(Map<String, dynamic> json) =>
      EmployeeProfileResponse(
        user: json["user"] == null
            ? null
            : EmployeeOrOperator.fromMap(json["user"]),
      );

  Map<String, dynamic> toJson() => {
        "user": user?.toJson(),
      };
}
