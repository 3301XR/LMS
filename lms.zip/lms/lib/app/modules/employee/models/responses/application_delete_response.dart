// To parse this JSON data, do
//
//     final employeeApplicationDeleteResponse = employeeApplicationDeleteResponseFromJson(jsonString);

import 'dart:convert';

class EmployeeApplicationDeleteResponse {
  EmployeeApplicationDeleteResponse({
    this.application,
  });

  String? application;

  factory EmployeeApplicationDeleteResponse.fromRawJson(String str) =>
      EmployeeApplicationDeleteResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory EmployeeApplicationDeleteResponse.fromJson(
          Map<String, dynamic> json) =>
      EmployeeApplicationDeleteResponse(
        application: json["application"],
      );

  Map<String, dynamic> toJson() => {
        "application": application,
      };
}
