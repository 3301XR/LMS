// To parse this JSON data, do
//
//     final applicationReturnResponse = applicationReturnResponseFromMap(jsonString);

import 'dart:convert';

import '../application.dart';

class ApplicationReturnResponse {
  ApplicationReturnResponse({
    this.application,
  });

  Application? application;

  factory ApplicationReturnResponse.fromJson(String str) =>
      ApplicationReturnResponse.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory ApplicationReturnResponse.fromMap(Map<String, dynamic> json) =>
      ApplicationReturnResponse(
        application: json["applications"] == null
            ? null
            : Application.fromMap(json["applications"]),
      );

  Map<String, dynamic> toMap() => {
        "applications": application?.toMap(),
      };
}
