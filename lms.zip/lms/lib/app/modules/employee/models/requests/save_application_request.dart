// To parse this JSON data, do
//
//     final saveApplicationRequest = saveApplicationRequestFromJson(jsonString);

import 'dart:convert';

class SaveApplicationRequest {
  SaveApplicationRequest({
    this.department,
    this.name,
    this.email,
    this.adminId,
    this.employeeId,
    this.reason,
    this.stay,
    this.start,
    this.end,
    this.totalDays,
  });

  String? department;
  String? name;
  String? email;
  String? adminId;
  String? employeeId;
  String? reason;
  String? stay;
  String? start;
  String? end;
  String? totalDays;

  factory SaveApplicationRequest.fromRawJson(String str) =>
      SaveApplicationRequest.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory SaveApplicationRequest.fromJson(Map<String, dynamic> json) =>
      SaveApplicationRequest(
        department: json["department"],
        name: json["name"],
        email: json["email"],
        adminId: json["admin_id"],
        employeeId: json["employee_id"],
        reason: json["reason"],
        stay: json["stay"],
        start: json["start"],
        end: json["end"],
        totalDays: json["total_days"],
      );

  Map<String, dynamic> toJson() => {
        "department": department,
        "name": name,
        "email": email,
        "admin_id": adminId,
        "employee_id": employeeId,
        "reason": reason,
        "stay": stay,
        "start": start,
        "end": end,
        "total_days": totalDays,
      };
}
