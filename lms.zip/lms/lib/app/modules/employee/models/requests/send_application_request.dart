import 'dart:convert';

class SendApplicationRequest {
  SendApplicationRequest({
    this.username,
    this.phone,
    this.password,
    this.branch,
    this.department,
    this.email,
    this.role,
    this.isActive,
  });

  String? username;
  String? phone;
  String? password;
  String? branch;
  String? department;
  String? email;
  String? role;
  String? isActive;

  factory SendApplicationRequest.fromRawJson(String str) =>
      SendApplicationRequest.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory SendApplicationRequest.fromJson(Map<String, dynamic> json) =>
      SendApplicationRequest(
        username: json["username"],
        phone: json["phone"],
        password: json["password"],
        branch: json["branch"],
        department: json["department"],
        email: json["email"],
        role: json["role"],
        isActive: json["is_active"],
      );

  Map<String, dynamic> toJson() => {
        "username": username,
        "phone": phone,
        "password": password,
        "branch": branch,
        "department": department,
        "email": email,
        "role": role,
        "is_active": isActive,
      };
}
