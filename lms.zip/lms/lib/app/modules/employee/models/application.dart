import 'dart:convert';

class Application {
  Application({
    this.id,
    this.name,
    this.department,
    this.adminId,
    this.employeeId,
    this.start,
    this.end,
    this.totalDays,
    this.total,
    this.reason,
    this.stay,
    this.approve,
    this.comment,
    this.applicationReturn,
    this.sent,
    this.createdAt,
    this.updatedAt,
  });

  int? id;
  String? name;
  String? department;
  String? adminId;
  int? employeeId;
  String? start;
  String? end;
  dynamic totalDays;
  int? total;
  String? reason;
  String? stay;
  dynamic approve;
  String? comment;
  dynamic applicationReturn;
  dynamic sent;
  String? createdAt;
  String? updatedAt;

  factory Application.fromJson(String str) =>
      Application.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory Application.fromMap(Map<String, dynamic> json) => Application(
        id: json["id"],
        name: json["name"],
        department: json["department"],
        adminId: json["admin_id"],
        employeeId: json["employee_id"],
        start: json["start"],
        end: json["end"],
        totalDays: json["total_days"],
        total: json["total"],
        reason: json["reason"],
        stay: json["stay"],
        approve: json["approve"],
        comment: json["comment"],
        applicationReturn: json["return"],
        sent: json["sent"],
        createdAt: json["created_at"],
        updatedAt: json["updated_at"],
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "name": name,
        "department": department,
        "admin_id": adminId,
        "employee_id": employeeId,
        "start": start,
        "end": end,
        "total_days": totalDays,
        "total": total,
        "reason": reason,
        "stay": stay,
        "approve": approve,
        "comment": comment,
        "return": applicationReturn,
        "sent": sent,
        "created_at": createdAt,
        "updated_at": updatedAt,
      };
}
