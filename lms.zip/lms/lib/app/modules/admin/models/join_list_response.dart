// To parse this JSON data, do
//
//     final joinListResponse = joinListResponseFromMap(jsonString);

import 'dart:convert';

class JoinListResponse {
  JoinListResponse({
    this.message,
    this.applications,
  });

  String? message;
  List<ApplicationList>? applications;

  factory JoinListResponse.fromJson(String str) =>
      JoinListResponse.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory JoinListResponse.fromMap(Map<String, dynamic> json) =>
      JoinListResponse(
        message: json["message"],
        applications: List<ApplicationList>.from(
            json["applications"].map((x) => ApplicationList.fromMap(x))),
      );

  Map<String, dynamic> toMap() => {
        "message": message,
        "applications": List<dynamic>.from(applications!.map((x) => x.toMap())),
      };
}

class ApplicationList {
  ApplicationList({
    this.id,
    this.username,
    this.email,
    this.password,
    this.role,
    this.isActive,
    this.phone,
    this.oparetorId,
    this.employeeId,
    this.token,
    this.createdAt,
    this.updatedAt,
  });

  int? id;
  String? username;
  String? email;
  String? password;
  String? role;
  String? isActive;
  String? phone;
  int? oparetorId;
  int? employeeId;
  int? token;
  String? createdAt;
  String? updatedAt;

  factory ApplicationList.fromJson(String str) =>
      ApplicationList.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory ApplicationList.fromMap(Map<String, dynamic> json) => ApplicationList(
        id: json["id"],
        username: json["username"],
        email: json["email"],
        password: json["password"],
        role: json["role"],
        isActive: json["is_active"],
        phone: json["phone"],
        oparetorId: json["oparetor_id"],
        employeeId: json["employee_id"],
        token: json["token"],
        createdAt: json["created_at"],
        updatedAt: json["updated_at"],
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "username": username,
        "email": email,
        "password": password,
        "role": role,
        "is_active": isActive,
        "phone": phone,
        "oparetor_id": oparetorId,
        "employee_id": employeeId,
        "token": token,
        "created_at": createdAt,
        "updated_at": updatedAt,
      };
}
