// To parse this JSON data, do
//
//     final applicationReturnCheckByIdResponse = applicationReturnCheckByIdResponseFromJson(jsonString);

import 'dart:convert';

import '../../employee/models/application.dart';

class ApplicationReturnCheckByIdResponse {
  ApplicationReturnCheckByIdResponse({
    this.application,
  });

  Application? application;

  factory ApplicationReturnCheckByIdResponse.fromRawJson(String str) =>
      ApplicationReturnCheckByIdResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory ApplicationReturnCheckByIdResponse.fromJson(
          Map<String, dynamic> json) =>
      ApplicationReturnCheckByIdResponse(
        application: json["application"] == null
            ? null
            : Application.fromJson(json["application"]),
      );

  Map<String, dynamic> toJson() => {
        "application": application == null ? null : application!.toJson(),
      };
}
