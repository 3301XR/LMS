import 'dart:convert';

class GenericResponse {
  String? message;

  GenericResponse({
    this.message,
  });

  factory GenericResponse.fromMap(Map<String, dynamic> json) => GenericResponse(
        message: json["message"],
      );

  factory GenericResponse.fromJson(String str) =>
      GenericResponse.fromMap(json.decode(str));

  Map<String, dynamic> toMap() => {
        "message": message,
      };

  String toJson() => json.encode(toMap());
}
