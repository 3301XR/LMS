// To parse this JSON data, do
//
//     final applicationCustomResponse = applicationCustomResponseFromMap(jsonString);

import 'dart:convert';

class ApplicationCustomResponse {
  ApplicationCustomResponse({
    this.applications,
  });

  String? applications;

  factory ApplicationCustomResponse.fromJson(String str) =>
      ApplicationCustomResponse.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory ApplicationCustomResponse.fromMap(Map<String, dynamic> json) =>
      ApplicationCustomResponse(
        applications: json["applications"],
      );

  Map<String, dynamic> toMap() => {
        "applications": applications,
      };
}
