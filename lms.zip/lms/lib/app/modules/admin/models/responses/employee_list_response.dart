// To parse this JSON data, do
//
//     final employeeListResponse = employeeListResponseFromMap(jsonString);

import 'dart:convert';

import 'package:lms/app/modules/auth/models/user.dart';
import 'package:lms/app/modules/employee/models/employee_or_operator.dart';

class EmployeeListResponse {
  EmployeeListResponse({
    this.message,
    this.employees,
  });

  String? message;
  List<EmployeeOrOperator>? employees;

  factory EmployeeListResponse.fromJson(String str) =>
      EmployeeListResponse.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory EmployeeListResponse.fromMap(Map<String, dynamic> json) =>
      EmployeeListResponse(
        message: json["message"],
        employees: json["employees"] == null
            ? null
            : List<EmployeeOrOperator>.from(
                json["employees"].map((x) => EmployeeOrOperator.fromMap(x))),
      );

  Map<String, dynamic> toMap() => {
        "message": message,
        "employees": employees == null
            ? null
            : List<dynamic>.from(employees!.map((x) => x.toMap())),
      };
}
