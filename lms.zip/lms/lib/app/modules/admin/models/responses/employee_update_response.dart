// To parse this JSON data, do
//
//     final employeeUpdateResponse = employeeUpdateResponseFromJson(jsonString);

import 'dart:convert';

import 'package:lms/app/modules/auth/models/user.dart';
import 'package:lms/app/modules/employee/models/employee_or_operator.dart';

class EmployeeUpdateResponse {
  EmployeeUpdateResponse({
    this.message,
    this.employee,
  });

  String? message;
  EmployeeOrOperator? employee;

  factory EmployeeUpdateResponse.fromRawJson(String str) =>
      EmployeeUpdateResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory EmployeeUpdateResponse.fromJson(Map<String, dynamic> json) =>
      EmployeeUpdateResponse(
        message: json["message"],
        employee: json["employee"] == null
            ? null
            : EmployeeOrOperator.fromMap(json["employee"]),
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "employee": employee == null ? null : employee!.toMap(),
      };
}
