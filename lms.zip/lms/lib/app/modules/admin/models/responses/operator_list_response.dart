import 'dart:convert';

import 'package:lms/app/modules/employee/models/employee_or_operator.dart';

class OperatorListResponse {
  OperatorListResponse({
    this.message,
    this.oparetors,
  });

  String? message;
  List<EmployeeOrOperator>? oparetors;

  factory OperatorListResponse.fromRawJson(String str) {
    return OperatorListResponse.fromJson(json.decode(str));
  }

  String toRawJson() => json.encode(toJson());

  factory OperatorListResponse.fromJson(Map<String, dynamic> json) =>
      OperatorListResponse(
        message: json["message"],
        oparetors: json["oparetors"] == null
            ? null
            : List<EmployeeOrOperator>.from(
                json["oparetors"].map((x) => EmployeeOrOperator.fromMap(x))),
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "oparetors": oparetors == null
            ? null
            : List<dynamic>.from(oparetors!.map((x) => x.toJson())),
      };
}
