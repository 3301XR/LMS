import 'dart:convert';

import 'package:lms/app/modules/auth/models/user.dart';

class GetEditAdminResponse {
  GetEditAdminResponse({
    this.message,
    this.admin,
  });

  String? message;
  User? admin;

  factory GetEditAdminResponse.fromRawJson(String str) =>
      GetEditAdminResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory GetEditAdminResponse.fromJson(Map<String, dynamic> json) =>
      GetEditAdminResponse(
        message: json["message"],
        admin: json["admin"] == null ? null : User.fromMap(json["admin"]),
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "admin": admin?.toMap(),
      };
}
