// To parse this JSON data, do
//
//     final dashboardResponse = dashboardResponseFromMap(jsonString);

import 'dart:convert';

import '../../../auth/models/user.dart';

class DashboardResponse {
  DashboardResponse({
    this.message,
    this.user,
    this.days,
    this.applications,
    this.join,
    this.leaveTaken,
    this.remaingLeave,
  });

  String? message;
  User? user;
  dynamic? days;
  dynamic? applications;
  dynamic? join;
  dynamic? leaveTaken;
  dynamic? remaingLeave;

  factory DashboardResponse.fromJson(String str) =>
      DashboardResponse.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory DashboardResponse.fromMap(Map<String, dynamic> json) =>
      DashboardResponse(
        message: json["message"],
        user: json["user"] == null ? null : User.fromMap(json["user"]),
        days: json["days"],
        applications: json["applications"],
        join: json["join"],
        leaveTaken: json["leaveTaken"],
        remaingLeave: json["remaingLeave"],
      );

  Map<String, dynamic> toMap() => {
        "message": message,
        "user": user == null ? null : user!.toMap(),
        "days": days,
        "applications": applications,
        "join": join,
        "leaveTaken": leaveTaken,
        "remaingLeave": remaingLeave,
      };
}
