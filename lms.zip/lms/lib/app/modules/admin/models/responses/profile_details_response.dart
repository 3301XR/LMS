// To parse this JSON data, do
//
//     final profileDetailsResponse = profileDetailsResponseFromMap(jsonString);

import 'dart:convert';

import 'package:lms/app/modules/employee/models/application.dart';
import 'package:lms/app/modules/employee/models/employee_or_operator.dart';

class ProfileDetailsResponse {
  ProfileDetailsResponse({
    this.user,
    this.takenleave,
    this.leftleave,
    this.application,
    this.phone,
  });

  EmployeeOrOperator? user;
  String? takenleave;
  String? leftleave;
  List<Application>? application;
  String? phone;

  factory ProfileDetailsResponse.fromJson(String str) =>
      ProfileDetailsResponse.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory ProfileDetailsResponse.fromMap(Map<String, dynamic> json) =>
      ProfileDetailsResponse(
        user: json["user"] == null
            ? null
            : EmployeeOrOperator.fromMap(json["user"]),
        takenleave: json["takenleave"],
        leftleave: json["leftleave"],
        application: json["application"] == null
            ? null
            : List<Application>.from(
                json["application"].map((x) => Application.fromMap(x))),
        phone: json["phone"],
      );

  Map<String, dynamic> toMap() => {
        "user": user?.toMap(),
        "takenleave": takenleave,
        "leftleave": leftleave,
        "application": application == null
            ? null
            : List<dynamic>.from(application!.map((x) => x.toMap())),
        "phone": phone,
      };
}
