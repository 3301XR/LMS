// To parse this JSON data, do
//
//     final operatorEditResponse = operatorEditResponseFromJson(jsonString);

import 'dart:convert';

import 'package:lms/app/modules/auth/models/user.dart';
import 'package:lms/app/modules/employee/models/employee_or_operator.dart';

class OperatorEditResponse {
  OperatorEditResponse({
    this.message,
    this.oparetor,
  });

  String? message;
  EmployeeOrOperator? oparetor;

  factory OperatorEditResponse.fromRawJson(String str) =>
      OperatorEditResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory OperatorEditResponse.fromJson(Map<String, dynamic> json) =>
      OperatorEditResponse(
        message: json["message"],
        oparetor: json["oparetor"] == null
            ? null
            : EmployeeOrOperator.fromMap(json["oparetor"]),
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "oparetor": oparetor == null ? null : oparetor!.toMap(),
      };
}
