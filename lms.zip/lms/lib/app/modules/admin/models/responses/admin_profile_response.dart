import 'dart:convert';

import '../../../auth/models/user.dart';

class AdminProfileResponse {
  AdminProfileResponse({
    this.message,
    this.user,
  });

  String? message;
  User? user;

  factory AdminProfileResponse.fromRawJson(String str) =>
      AdminProfileResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory AdminProfileResponse.fromJson(Map<String, dynamic> json) =>
      AdminProfileResponse(
        message: json["message"],
        user: json["user"] == null ? null : User.fromMap(json["user"]),
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "user": user == null ? null : user!.toJson(),
      };
}
