import 'package:get/get.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/shared/controllers/base_controller.dart';

import '../../../employee/models/application.dart';
import '../../models/join_list_response.dart';

class JoinListVm extends BaseController {
  final joinListResponse = <ApplicationList>[].obs;
  final allJoinListResponse = <ApplicationList>[].obs;
  final AdminRepository adminRepository = Get.find();

  getJoinList() async {
    isLoading.value = true;
    final response = await adminRepository.getApplicationJoinList();
    isLoading.value = false;
    print(response);
    response.fold(
      (l) => null,
      (r) {
        joinListResponse.assignAll(r.applications?.reversed ?? []);
        allJoinListResponse.assignAll(r.applications?.reversed ?? []);
      },
    );
  }

  void onSearch(String v) {
    joinListResponse.assignAll(allJoinListResponse
        .where((p0) => p0.toJson().toLowerCase().contains(v.toLowerCase())));
  }

  @override
  onInit() async {
    super.onInit();
    await getJoinList();
  }
}
