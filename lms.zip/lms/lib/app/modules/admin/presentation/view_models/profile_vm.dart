import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/modules/auth/models/requests/create_update_user_request.dart';
import 'package:lms/app/modules/auth/models/responses/login_response.dart';

import '../../models/responses/admin_profile_response.dart';

class AdminProfileVM extends GetxController {
  final AdminRepository _adminRepository = Get.find();
  final profileResponse = Rxn<AdminProfileResponse>();

  var nameController = TextEditingController();

  var phoneController = TextEditingController();

  var emailController = TextEditingController();

  var passwordController = TextEditingController();

  getAdminProfile() async {
    var response = await _adminRepository.getAdminProfile();
    response.fold((l) => null, (r) {
      profileResponse.value = r;
    });
  }

  initData() {
    nameController.text = profileResponse.value?.user?.username ?? '';
    phoneController.text = profileResponse.value?.user?.phone ?? '';
    emailController.text = profileResponse.value?.user?.email ?? '';
    passwordController.text = profileResponse.value?.user?.password ?? '';
  }

  @override
  onInit() async {
    super.onInit();
    await getAdminProfile();
    initData();
  }

  updateProfile() async {
    var response = await _adminRepository.adminEdit(
        profileResponse.value!.user!.id!,
        CreateUpdateUserRequest(
          username: nameController.text,
          phone: phoneController.text,
          email: emailController.text,
          password: passwordController.text,
        ));

    print(response);
    response.fold((l) {
      Get.snackbar('Error', l.message,
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
          borderRadius: 10,
          margin: EdgeInsets.all(10));
    }, (r) async {
      Get.snackbar('Success', 'Profile Updated Successfully',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.green,
          colorText: Colors.white,
          borderRadius: 10,
          margin: EdgeInsets.all(10));
    });

    await getAdminProfile();
  }
}
