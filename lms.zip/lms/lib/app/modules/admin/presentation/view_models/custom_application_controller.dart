import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../auth/repositories/auth_repository.dart';
import '../../repositories/admin_repository.dart';

class CustomApplicationForSuperAdminController extends GetxController {
  final int id;
  final String comment;
  final String start;
  final String end;
  final String? days;
  final AdminRepository _adminRepository = Get.find();
  final AuthRepository _authRepository = Get.find();

  var startDateController = TextEditingController();

  var toDateController = TextEditingController();

  var commentController = TextEditingController();

  CustomApplicationForSuperAdminController(
      {required this.id,
      required this.comment,
      required this.start,
      required this.end,
      required this.days});

  // void onDeleted() {}

  initData() {
    startDateController.text = start;
    toDateController.text = end;
  }

  getCustomApplication(int id, String comment, String start, String end) async {
    var response =
        await _adminRepository.getApplicationCustom(id, comment, start, end);
    response.fold((l) => null, (r) {
      Get.snackbar('Success', 'Approved Successful');
      Get.close(2);
    });
  }

  @override
  onInit() async {
    super.onInit();

    await initData();
  }
}
