import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:darq/darq.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/modules/auth/models/responses/login_response.dart';
import 'package:lms/app/modules/auth/models/user.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/models/requests/save_application_request.dart';
import 'package:lms/app/modules/employee/repositories/employee_repository.dart';
import 'package:lms/app/shared/widgets/snackbars.dart';

import '../views/pages/all_application_list.dart';

class ApplicationFromController extends GetxController {
  final AdminRepository _adminRepository = Get.find<AdminRepository>();
  final AuthRepository _authRepository = Get.find<AuthRepository>();
  final EmployeeRepository _employeeRepository = Get.find<EmployeeRepository>();
  final selectedOparetor = Rxn<User>();
  final selectedLeaveReason = Rxn<String>();

  var fromDateController = TextEditingController();

  var toDateController = TextEditingController();

  final operatorList = <User>[].obs;
  final reasonList = <String>['শারীরিক অসুস্থতা', 'পারিবারিক', 'অন্যান্য'];

  var locationController = TextEditingController();

  var otherReasonController = TextEditingController();

  final loginResponse = Rxn<LoginResponse>();
  final employee = Rxn<User>();

  onConfirm() async {
    //TODO : fix according to the backend fix
    // final employeeResponse =
    //     await _adminRepository.getEmployeeDetails(user.value!.id!);
    // employeeResponse.fold((l) => null, (r) {
    //   return employee.value = r.user;
    // });

    final response =
        await _employeeRepository.saveSendApplication(SaveApplicationRequest(
      adminId: selectedOparetor.value?.id.toString(),
      // department: loginResponse.value?.department,
      department: "department",
      email: loginResponse.value?.data?.email,
      employeeId: loginResponse.value?.data?.id.toString(),
      start: fromDateController.text,
      stay: locationController.text,
      reason: otherReasonController.text.isNotEmpty
          ? otherReasonController.text
          : selectedLeaveReason.value,
      end: toDateController.text,
      name: loginResponse.value!.data?.username,
      totalDays: (DateTime.parse(toDateController.text)
                  .difference(DateTime.parse(fromDateController.text))
                  .inDays +
              1)
          .toString(),
    ));
    response.fold((l) => Get.snackbar("Error", l.message), (r) {
      if (r.message?.contains('উক্ত') ?? false) {
        MySnackBars.showErrorSnackBar(r.message!);
      } else {
        Get.off(() => AllApplicationList());
        MySnackBars.showSuccessSnackBar(r.message!);
      }
    });
  }

  getOperatorList() async {
    final response = await _employeeRepository.getSendApplication();

    response.fold((l) => null, (r) {
      var withoutCU =
          r.user!.where((e) => e.id != loginResponse.value?.data?.id).toList();
      operatorList.assignAll(withoutCU);
    });
  }

  getLoginResponse() async {
    final response = await _authRepository.getLoginResponse();

    response.fold((l) => null, (r) => loginResponse.value = r);
  }

  @override
  onInit() async {
    super.onInit();
    await getLoginResponse();
    await getOperatorList();
  }

  void onReset() {
    fromDateController.text = '';
    toDateController.text = '';
    locationController.text = '';
    otherReasonController.text = '';
    selectedOparetor.value = null;
    selectedLeaveReason.value = null;
  }
}
