import 'package:get/get.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/modules/employee/models/employee_or_operator.dart';
import 'package:lms/app/shared/values/filter_data.dart';
import 'package:lms/app/shared/widgets/snackbars.dart';

import '../../models/responses/profile_details_response.dart';

class AdminController extends GetxController {
  final operatorList = <EmployeeOrOperator>[].obs;
  final allOperatorList = <EmployeeOrOperator>[].obs;
  final operatorDetails = Rxn<ProfileDetailsResponse>();
  final AdminRepository _adminRepository = Get.find();

  final id = 0.obs;

  getAdminList() async {
    final response = await _adminRepository.getOperatorList();

    response.fold((l) => print(l.message), (r) {
      operatorList.value = r.oparetors!;
      allOperatorList.assignAll(r.oparetors ?? []);
    });
  }

  getAdminDetails(int id) async {
    final response = await _adminRepository.getOperatorProfileDetails(id);

    response.fold((l) => null, (r) => operatorDetails.value = r);
  }

  onDeleted(int id) async {
    final response = await _adminRepository.getOperatorDelete(id);

    response.fold((l) => MySnackBars.showErrorSnackBar(l.message), (r) async {
      Get.back();
      MySnackBars.showSuccessSnackBar(r.message!);
      await getAdminList();
    });
  }

  @override
  onInit() async {
    super.onInit();
    await getAdminList();
  }

  void onSearch(String v) {
    operatorList.assignAll(allOperatorList
        .where((p0) => p0.toJson().toLowerCase().contains(v.toLowerCase())));
  }
}
