# View Models

View Models are the presentation logic handler of the application.

Usually takes or provides data to the view.