import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../auth/repositories/auth_repository.dart';
import '../../../employee/models/application.dart';
import '../../repositories/admin_repository.dart';

class PendingApplicationForSuperAdminController extends GetxController {
  final isHealthExpanded = <bool>[].obs;

  final AdminRepository _adminRepository = Get.find();
  final AuthRepository _authRepository = Get.find();
  final id = 0.obs;
  final applicationList = <Application>[].obs;
  final allApplicationList = <Application>[].obs;

  var startDateController = TextEditingController();

  var toDateController = TextEditingController();

  var comment = TextEditingController();

  // void onDeleted() {}

  getId() async {
    final loginResponse = await _authRepository.getLoginResponse();
    loginResponse.fold((l) => null, (r) => id.value = r.data!.id!);
  }

  getPendingMyApplicationList() async {
    final response = await _adminRepository.pendingApplication();

    response.fold((l) => null, (r) {
      allApplicationList.assignAll(r.applications!);
      applicationList.assignAll(r.applications!);
    });
  }

  applicationReturn(int id) async {
    var response = await _adminRepository.geConfirmApplication(id);
    response.fold((l) => null, (r) {
      Get.snackbar('Success', 'Approved Successful');
      getPendingMyApplicationList();
    });
  }

  applicationRejected(int id) async {
    var response = await _adminRepository.geRejectedApplication(id);
    response.fold((l) => null, (r) {
      Get.snackbar('Success', 'Rejected Successful');
      getPendingMyApplicationList();
    });
  }

  @override
  onInit() async {
    super.onInit();
    await getId();
    await getPendingMyApplicationList();
  }

  void onSearch(String v) {
    applicationList.assignAll(allApplicationList
        .where((p0) => p0.toJson().toLowerCase().contains(v.toLowerCase())));
  }
}
