import 'package:get/get.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/models/application.dart';

import '../../../super_admin/presentation/views/pages/leave_list_screen.dart';
import '../../models/responses/operator_dashboard_response.dart';

class DashboardForAdminController extends GetxController {
  final dashboardResponse = Rxn<DashboardResponse>();
  final AdminRepository _adminRepository = Get.find();

  final pendingApplicationList = <Application>[].obs;

  getDashboardData() async {
    final response = await _adminRepository.getOperatorDashboard();
    response.fold((l) => null, (r) => dashboardResponse.value = r);
  }

  onLeaveInfo() {
    Get.to(() => LeaveListScreen());
  }

  getPendingMyApplicationList() async {
    final response = await _adminRepository.pendingApplication();

    response.fold(
        (l) => null, (r) => pendingApplicationList.assignAll(r.applications!));
  }

  @override
  onInit() async {
    super.onInit();
    await getPendingMyApplicationList();
    await getDashboardData();
  }
}
