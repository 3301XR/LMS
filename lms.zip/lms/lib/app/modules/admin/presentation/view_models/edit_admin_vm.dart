import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:lms/app/modules/admin/presentation/view_models/admin_controller.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/shared/models/branch.dart';
import 'package:lms/app/shared/models/department.dart';

import '../../../auth/models/requests/create_update_user_request.dart';
import '../../models/responses/employee_update_response.dart';
import '../../models/responses/operator_edit_response.dart';

class EditAdminVM extends GetxController {
  final selectedBranch = Rxn<Branch>();
  final selectedDesignation = Rxn<Designation>();

  var userNameController = TextEditingController();

  var phoneNumberController = TextEditingController();

  var emailController = TextEditingController();

  var passwordController = TextEditingController();

  final editData = Rxn<OperatorEditResponse>();

  final AdminRepository _adminRepository = Get.find();
  final operatorUpdate = Rxn<OperatorEditResponse>();
  final _adminController = Get.put(AdminController());

  var dropdownValidatorDesignation = false.obs;
  var dropdownValidatorSakha = false.obs;

  getEditOperator(int id) async {
    final response = await _adminRepository.getOperatorEdit(id);
    response.fold((l) => null, (r) {
      editData.value = r;
      fetchForEdit();
    });
  }

  fetchForEdit() {
    userNameController.text = editData.value?.oparetor?.firstName ?? '';
    emailController.text = editData.value?.oparetor?.email ?? '';
    phoneNumberController.text = editData.value?.oparetor?.phone ?? '';
    passwordController.text = editData.value?.oparetor?.password ?? '';
  }

  updateData() async {
    final response = await _adminRepository.operatorUpdate(
        editData.value!.oparetor!.id!,
        CreateUpdateUserRequest(
            firstName: userNameController.text,
            branch: selectedBranch.value!.name,
            department: selectedDesignation.value!.name,
            email: emailController.text,
            isActive: 1,
            password: passwordController.text,
            phone: phoneNumberController.text,
            role: 3));
    response.fold((l) => null, (r) async {
      operatorUpdate.value = r;
      Get.back();
      Get.snackbar('Success!', 'Operator Update Successful');
      await _adminController.getAdminList();
    });
  }

  @override
  onInit() async {
    super.onInit();
    fetchForEdit();
  }
}
