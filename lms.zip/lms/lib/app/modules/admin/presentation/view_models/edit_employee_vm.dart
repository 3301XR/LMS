import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/shared/models/branch.dart';

import '../../../auth/models/requests/create_update_user_request.dart';
import '../../models/responses/employee_update_response.dart';
import 'employee_list_vm.dart';

class EditEmployeeVM extends GetxController {
  final AdminRepository _adminRepository = Get.find();

  final name = TextEditingController();

  final mobile = TextEditingController();

  final email = TextEditingController();

  final newPassword = TextEditingController();

  var designation = TextEditingController();

  var selectedBranch = Rxn<Branch>();

  final dropdownValidator = false.obs;

  final editData = Rxn<EmployeeUpdateResponse>();
  final employeeUpdate = Rxn<EmployeeUpdateResponse>();

  getEditEmployee(int id) async {
    final response = await _adminRepository.getEmployeeEdit(id);
    response.fold((l) => null, (r) {
      editData.value = r;
      fetchForEdit();
    });
  }

  fetchForEdit() {
    name.text = editData.value?.employee?.firstName ?? '';
    email.text = editData.value?.employee?.email ?? '';
    mobile.text = editData.value?.employee?.phone ?? '';
    newPassword.text = editData.value?.employee?.password ?? '';
    designation.text = editData.value?.employee?.department ?? '';
  }

  updateData() async {
    final response = await _adminRepository.employeeUpdate(
        editData.value!.employee!.id!,
        CreateUpdateUserRequest(
            firstName: name.text,
            branch: selectedBranch.value!.name,
            department: designation.text,
            email: email.text,
            isActive: 1,
            password: newPassword.text,
            phone: mobile.text,
            role: 3));
    response.fold((l) => null, (r) {
      employeeUpdate.value = r;
      Get.back();
      Get.snackbar('Success!', 'Employee Update Successful');

      Get.find<EmployeeListVm>().getEmployeeList();
    });
  }

// @override
// onInit() async {
//   super.onInit();
//   fetchForEdit();
// }
}
