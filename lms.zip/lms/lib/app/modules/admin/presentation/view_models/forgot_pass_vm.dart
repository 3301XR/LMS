import 'package:get/get.dart';

class ForgotPasswordController extends GetxController {
  final role = "Admin".obs;

  var email;

  void onSendCode() {
    print("Send Code");
  }

  onChangeRole(String newValue) {
    role.value = newValue;
  }
}
