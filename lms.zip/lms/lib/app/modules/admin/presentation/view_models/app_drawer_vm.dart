import 'package:get/get.dart';

class AppDrawerVM extends GetxController {
  final activeAdmin = false.obs;
  final employeeActive = false.obs;
  final activeApplication = false.obs;
  final isLoading = false.obs;

  @override
  void onInit() async {
    super.onInit();
  }

  teacherLogout() async {}
}
