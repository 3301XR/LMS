import 'package:get/get.dart';
import 'package:lms/app/shared/values/filter_data.dart';

import '../../../auth/repositories/auth_repository.dart';
import '../../../employee/models/application.dart';
import '../../repositories/admin_repository.dart';

class AllApplicationController extends GetxController {
  final AdminRepository _adminRepository = Get.find();
  final id = 0.obs;
  final allApplicationList = <Application>[].obs;
  final applicationList = <Application>[].obs;
  final isHealthExpanded = <bool>[].obs;

  getAllApplication() async {
    final response = await _adminRepository.getPendingLeaveApplication();

    response.fold((l) => null, (r) {
      allApplicationList.assignAll(r.applications!.reversed);
      applicationList.assignAll(r.applications!.reversed);
    });
  }

  @override
  onInit() async {
    super.onInit();
    await getAllApplication();
  }

  void onDeleted(int id) {}

  void onSearch(String v) {
    if (selectedFilter.value?.key == "") {
      applicationList.assignAll(allApplicationList
          .where((p0) => p0.toJson().toLowerCase().contains(v.toLowerCase())));
    } else {
      applicationList.assignAll(allApplicationList.where((p0) =>
          p0.approve == selectedFilter.value?.key &&
          p0.toJson().toLowerCase().contains(v.toLowerCase())));
    }
  }

  var selectedFilter = Rxn<ApplicationStatus>();

  void onFilter(ApplicationStatus? v) {
    if (v?.key == "") {
      applicationList.assignAll(allApplicationList);
    } else {
      applicationList
          .assignAll(allApplicationList.where((p0) => p0.approve == v!.key));
    }
  }
}
