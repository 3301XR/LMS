import 'package:get/get.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/modules/auth/models/user.dart';
import 'package:lms/app/modules/employee/models/employee_or_operator.dart';
import 'package:lms/app/shared/values/filter_data.dart';
import 'package:lms/app/shared/widgets/snackbars.dart';

import '../../models/responses/profile_details_response.dart';

class EmployeeListVm extends GetxController {
  final employeeList = <EmployeeOrOperator>[].obs;
  final allEmployeeList = <EmployeeOrOperator>[].obs;
  final employeeDetails = Rxn<ProfileDetailsResponse>();
  final AdminRepository _adminRepository = Get.find();

  getEmployeeList() async {
    final response = await _adminRepository.getEmployeeList();

    response.fold((l) => print(l.message), (r) {
      employeeList.assignAll(r.employees ?? []);
      allEmployeeList.assignAll(r.employees ?? []);
    });
  }

  getEmployeeDetails(int id) async {
    final response = await _adminRepository.getEmployeeDetails(id);
    response.fold((l) => null, (r) => employeeDetails.value = r);
  }

  void onDeleted(int id) async {
    final response = await _adminRepository.deleteEmployee(id);
    response.fold((l) => MySnackBars.showErrorSnackBar(l.message), (r) async {
      Get.back();
      MySnackBars.showSuccessSnackBar(r.message!);
      await getEmployeeList();
    });
  }

  @override
  onInit() async {
    super.onInit();
    await getEmployeeList();
  }

  void onSearch(String v) {
    employeeList.assignAll(allEmployeeList
        .where((p0) => p0.toJson().toLowerCase().contains(v.toLowerCase())));
  }
}
