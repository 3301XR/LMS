import 'package:get/get.dart';
import 'package:lms/app/modules/admin/repositories/admin_repository.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/shared/values/filter_data.dart';

import '../../../employee/models/application.dart';

class MyApplicationVM extends GetxController {
  final isHealthExpanded = <bool>[].obs;

  final AdminRepository _adminRepository = Get.find();
  final AuthRepository _authRepository = Get.find();
  final id = 0.obs;
  final applicationList = <Application>[].obs;
  final allApplicationList = <Application>[].obs;
  // void onDeleted() {}

  getMyApplicationList() async {
    final loginResponse = await _authRepository.getLoginResponse();
    loginResponse.fold((l) => null, (r) => id.value = r.data!.id!);
    final response = await _adminRepository.getApplicationList(id.value);
    response.fold((l) => null, (r) {
      allApplicationList.assignAll(r.applications ?? []);
      applicationList.assignAll(r.applications ?? []);
    });
  }

  @override
  onInit() async {
    super.onInit();
    await getMyApplicationList();
  }

  void onSearch(String v) {
    if (selectedFilter.value?.key == "") {
      applicationList.assignAll(allApplicationList
          .where((p0) => p0.toJson().toLowerCase().contains(v.toLowerCase())));
    } else {
      applicationList.assignAll(allApplicationList.where((p0) =>
          p0.approve == selectedFilter.value?.key &&
          p0.toJson().toLowerCase().contains(v.toLowerCase())));
    }
  }

  var selectedFilter = Rxn<ApplicationStatus>();

  void onFilter(ApplicationStatus? v) {
    if (v?.key == "") {
      applicationList.assignAll(allApplicationList);
    } else {
      applicationList
          .assignAll(allApplicationList.where((p0) => p0.approve == v!.key));
    }
  }
}
