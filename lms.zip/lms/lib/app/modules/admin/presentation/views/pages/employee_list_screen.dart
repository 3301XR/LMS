import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../view_models/edit_employee_vm.dart';
import '../../view_models/employee_list_vm.dart';
import 'admin_details_screen.dart';
import 'edit_employee_screen.dart';
import 'employee_details_screen.dart';

class EmployeeListScreen extends StatelessWidget {
  EmployeeListScreen({Key? key}) : super(key: key) {
    controller = Get.put(EmployeeListVm());
  }

  late final EmployeeListVm controller;
  final EditEmployeeVM editEmployeeVM = Get.put(EditEmployeeVM());

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text('কর্মকর্তা/কর্মচারীর তালিকা'),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 10.0, right: 10.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      onChanged: (v) {
                        controller.onSearch(v);
                      },
                      decoration: InputDecoration(
                          contentPadding: const EdgeInsets.only(left: 20),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5),
                              borderSide: const BorderSide(
                                color: Colors.grey,
                              )),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5),
                              borderSide: const BorderSide(
                                color: Colors.grey,
                              )),
                          hintText: "Search"),
                    ),
                  ),
                ),
              ],
            ),
            Expanded(
              child: Obx(() {
                return ListView.builder(
                  shrinkWrap: true,
                  itemCount: controller.employeeList.length,
                  itemBuilder: (context, index) => Container(
                    margin: const EdgeInsets.all(5),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 1,
                          blurRadius: 1,
                          offset:
                              const Offset(1, 1), // changes position of shadow
                        ),
                      ],
                      color: Colors.white,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: width * 0.55,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Text(
                                    'নাম ও পদবি: ',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12),
                                  ),
                                  Flexible(
                                    child: Text(
                                      controller
                                              .employeeList[index].firstName ??
                                          "",
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 12),
                                    ),
                                  ),
                                ],
                              ),
                              Text(
                                controller.employeeList[index].department ?? "",
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 12),
                              ),
                              const SizedBox(
                                height: 5,
                              ),
                              Row(
                                children: [
                                  const Text(
                                    'ইমেইল: ',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12),
                                  ),
                                  Flexible(
                                    child: Text(
                                      controller.employeeList[index].email ??
                                          "",
                                      style: const TextStyle(fontSize: 12),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  const Text(
                                    'মোবাইল: ',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12),
                                  ),
                                  Text(
                                    controller.employeeList[index].phone ?? "",
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Row(
                            children: [
                              Expanded(
                                child: IconButton(
                                    onPressed: () async {
                                      await editEmployeeVM.getEditEmployee(
                                          controller.employeeList[index].id!);
                                      Get.to(() => EditEmployeeScreen());
                                    },
                                    icon: Icon(
                                      Icons.edit,
                                      color: Colors.grey[600],
                                    )),
                              ),
                              Expanded(
                                child: IconButton(
                                    onPressed: () {
                                      showDeletePopup(context,
                                          controller.employeeList[index].id!);
                                    },
                                    icon: Icon(
                                      Icons.delete,
                                      color: Colors.grey[600],
                                    )),
                              ),
                              Expanded(
                                child: IconButton(
                                    onPressed: () async {
                                      await controller.getEmployeeDetails(
                                          controller.employeeList[index].id!);
                                      Get.to(() => EmployeeDetailsScreen());
                                    },
                                    icon: Icon(
                                      Icons.remove_red_eye,
                                      color: Colors.grey[600],
                                    )),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  showDeletePopup(BuildContext context, int id) {
    // set up the button
    Widget okButton = Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        InkWell(
          onTap: () {
            Get.back();
          },
          child: const Padding(
            padding: EdgeInsets.all(15),
            child: Text('বাতিল'),
          ),
        ),
        InkWell(
          onTap: () {
            controller.onDeleted(id);
          },
          child: const Padding(
            padding: EdgeInsets.all(15),
            child: Text('মুছে ফেলুন'),
          ),
        )
      ],
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("আপনি মুছে ফেলতে চান"),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
