import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../view_models/profile_vm.dart';
import '../widgets/auth_field_widget.dart';

class EditProfileScreen extends GetView<AdminProfileVM> {
  final _formKey = GlobalKey<FormState>();

  EditProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var sizedBox = const SizedBox(
      height: 10,
    );
    return Scaffold(
      appBar: AppBar(
        title: const Text('হালনাগাদ প্রোফাইল'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 15.0, right: 15.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                sizedBox,
                sizedBox,
                MyAuthFormField(
                  labelText: 'ব্যবহারকারীর নাম',
                  hinText: 'ব্যবহারকারীর নাম',
                  controller: controller.nameController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'ব্যবহারকারীর নাম দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                MyAuthFormField(
                  labelText: 'মোবাইল',
                  hinText: '01700000000',
                  controller: controller.phoneController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'মোবাইল নম্বর দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                MyAuthFormField(
                  labelText: 'ইমেইল',
                  hinText: 'xxx@mail.com',
                  controller: controller.emailController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'ইমেইল দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                MyAuthFormField(
                  labelText: 'নতুন পাসওয়ার্ড',
                  hinText: '********',
                  obscureText: true,
                  maxLines: 1,
                  controller: controller.passwordController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'নতুন পাসওয়ার্ড দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                sizedBox,
                sizedBox,
                InkWell(
                  onTap: () async {
                    if (_formKey.currentState!.validate()) {
                      Get.back();
                      await controller.updateProfile();
                    }
                  },
                  child: Container(
                      height: 35,
                      width: 150,
                      decoration: BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.circular(5)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Text(
                            'হালনাগাদ প্রোফাইল',
                            style: TextStyle(color: Colors.white),
                          ),
                        ],
                      )),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
