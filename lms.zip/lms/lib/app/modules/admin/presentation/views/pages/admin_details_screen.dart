import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../view_models/admin_controller.dart';

class AdminProfileDetailsScreen extends StatelessWidget {
  AdminProfileDetailsScreen({Key? key}) : super(key: key) {
    controller = Get.put(AdminController());
  }

  late final AdminController controller;

  @override
  Widget build(BuildContext context) {
    var sizedBox = const SizedBox(
      height: 20,
    );
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text(
          'প্রোফাইল',
          style: TextStyle(color: Colors.white),
        ),
        leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: const Icon(
              Icons.arrow_back_ios_rounded,
              color: Colors.white,
            )),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            sizedBox,
            Container(
                decoration: const BoxDecoration(color: Color(0XFFD4DBF9)),
                height: 80,
                width: MediaQuery.of(context).size.width,
                child: Padding(
                  padding: const EdgeInsets.only(left: 0, right: 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text('প্রোফাইলে স্বাগতম!'),
                            Obx(() {
                              return Text(controller
                                      .operatorDetails.value?.user?.firstName ??
                                  "");
                            }),
                          ],
                        ),
                      ),
                      Image.asset(
                        'assets/profile-img.png',
                        fit: BoxFit.cover,
                      ),
                    ],
                  ),
                )),
            sizedBox,
            Padding(
              padding: const EdgeInsets.only(left: 15.0, right: 15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'অ্যাডমিন',
                        style: TextStyle(fontSize: 18),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            sizedBox,
            Padding(
              padding: const EdgeInsets.only(left: 15.0, right: 15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Obx(() {
                        return Text(
                          'পদবী: ${controller.operatorDetails.value?.user?.department ?? ""}',
                          style: const TextStyle(fontSize: 15),
                        );
                      }),
                      Obx(() {
                        return Text(
                          'ইমেইল: ${controller.operatorDetails.value?.user?.email ?? ""}',
                          style: const TextStyle(fontSize: 15),
                        );
                      }),
                    ],
                  ),
                ],
              ),
            ),
            sizedBox,
            Padding(
              padding: const EdgeInsets.only(left: 15.0, right: 15.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'ব্যক্তিগত তথ্য',
                        style: TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.25,
                        child: const Text(
                          'নাম:',
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                      SizedBox(
                        width: width * 0.6,
                        child: Text(
                          controller.operatorDetails.value?.user?.firstName ??
                              "",
                          style: const TextStyle(fontSize: 15),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.25,
                        child: const Text(
                          'মুঠোফোন :',
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                      SizedBox(
                        width: width * 0.6,
                        child: Text(
                          controller.operatorDetails.value?.phone ?? "",
                          style: const TextStyle(fontSize: 15),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.25,
                        child: const Text(
                          'ইমেইল  :',
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                      SizedBox(
                        width: width * 0.6,
                        child: Text(
                          controller.operatorDetails.value?.user?.email ?? "",
                          style: const TextStyle(fontSize: 15),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.25,
                        child: const Text(
                          'শাখা   :',
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                      SizedBox(
                        width: width * 0.6,
                        child: Text(
                          controller.operatorDetails.value?.user?.branch ?? "",
                          style: const TextStyle(fontSize: 15),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.25,
                        child: const Text(
                          'ভোগকৃত ছুটি :',
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                      SizedBox(
                        width: width * 0.6,
                        child: Obx(() {
                          return Text(
                            '${controller.operatorDetails.value?.takenleave ?? ""} দিন',
                            style: const TextStyle(fontSize: 15),
                          );
                        }),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.25,
                        child: const Text(
                          'অবশিষ্ট ছুটি :',
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                      SizedBox(
                        width: width * 0.6,
                        child: Obx(() {
                          return Text(
                            '${controller.operatorDetails.value?.leftleave ?? ""} দিন',
                            style: TextStyle(fontSize: 15),
                          );
                        }),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            sizedBox,
            Obx(() {
              return ListView.builder(
                shrinkWrap: true,
                itemCount:
                    controller.operatorDetails.value?.application?.length ?? 0,
                itemBuilder: (context, index) => Container(
                    width: width,
                    margin: const EdgeInsets.only(
                        top: 10, bottom: 10, left: 10, right: 10),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: Colors.grey.shade200),
                        borderRadius: BorderRadius.circular(5)),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              const Text(
                                'আবেদনের তারিখ: ',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 12),
                              ),
                              Flexible(
                                child: Text(
                                  controller.operatorDetails.value
                                          ?.application![index].createdAt ??
                                      "",
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              const Text(
                                'তারিখ হতে:',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 12),
                              ),
                              Flexible(
                                child: Text(
                                  controller.operatorDetails.value
                                          ?.application![index].start ??
                                      "",
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              const Text(
                                'তারিখ পর্যন্ত: ',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 12),
                              ),
                              Flexible(
                                child: Text(
                                  controller.operatorDetails.value
                                          ?.application![index].end ??
                                      "",
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              const Text(
                                'আবেদনকৃত ছুটি: ',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 12),
                              ),
                              Flexible(
                                child: Text(
                                  controller.operatorDetails.value
                                          ?.application![index].totalDays
                                          .toString() ??
                                      "",
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              const Text(
                                'অনুমোদিত ছুটি: ',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 12),
                              ),
                              Flexible(
                                child: Text(
                                  controller.operatorDetails.value
                                          ?.application![index].total
                                          .toString() ??
                                      "",
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              const Text(
                                'অবস্থান: ',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 12),
                              ),
                              Flexible(
                                child: Text(
                                  controller.operatorDetails.value
                                          ?.application![index].stay ??
                                      "",
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              const Text(
                                'কারণ: ',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 12),
                              ),
                              Flexible(
                                child: Text(
                                  controller.operatorDetails.value
                                          ?.application![index].reason ??
                                      "",
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              const Text(
                                'অবস্থা: ',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 12),
                              ),
                              Flexible(
                                child: controller.operatorDetails.value
                                            ?.application![index].approve ==
                                        "1"
                                    ? const Text(
                                        ' অনুমোদিত',
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                            fontSize: 18, color: Colors.green),
                                      )
                                    : controller.operatorDetails.value
                                                ?.application![index].approve ==
                                            "0"
                                        ? const Text(
                                            ' প্রত্যাখ্যাত',
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                                fontSize: 18,
                                                color: Colors.red),
                                          )
                                        : Text(
                                            ' অপেক্ষমাণ..',
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                                fontSize: 18,
                                                color: Colors.green[300]),
                                          ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    )),
              );
            })
          ],
        ),
      ),
    );
  }
}
