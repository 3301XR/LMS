import 'package:flutter/material.dart';

class MyAuthFormField extends StatelessWidget {
  final FormFieldSetter<String>? onSaved;
  final String labelText;
  final String? hinText;
  final bool? obscureText;
  final bool? readOnly;
  final VoidCallback? onTap;
  final TextEditingController? controller;
  final int? maxLines;
  final FormFieldValidator<String>? validator;

  const MyAuthFormField(
      {Key? key,
      this.onSaved,
      this.controller,
      required this.labelText,
      this.hinText,
      this.readOnly = false,
      this.obscureText = false,
      this.onTap,
      this.maxLines,
      this.validator})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Text(
              labelText,
              style: const TextStyle(
                color: Color(0xff2E3A59),
              ),
            ),
          ],
        ),
        TextFormField(
          controller: controller,
          onTap: onTap,
          obscureText: obscureText!,
          readOnly: readOnly!,
          // textAlign: TextAlign.center,
          textAlignVertical: TextAlignVertical.center,
          maxLines: maxLines,
          onSaved: onSaved,
          validator: validator,
          decoration: InputDecoration(
            hintText: hinText,
            hintStyle: const TextStyle(fontSize: 13),
            contentPadding: const EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 10.0),
            fillColor: const Color(0XFFE5EAFC),
            // filled: true,
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5),
                borderSide: const BorderSide(
                  color: Colors.grey,
                )),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5),
                borderSide: const BorderSide(
                  color: Colors.grey,
                )),
          ),
        ),
      ],
    );
  }
}
