import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/shared/models/branch.dart';
import 'package:lms/app/shared/values/colors.dart';

import '../../view_models/edit_employee_vm.dart';
import '../widgets/auth_field_widget.dart';

class EditEmployeeScreen extends GetView<EditEmployeeVM> {
  final _formKey = GlobalKey<FormState>();

  EditEmployeeScreen({Key? key}) : super(key: key);
  final EditEmployeeVM addEmployeeVM = Get.put(EditEmployeeVM());

  @override
  Widget build(BuildContext context) {
    var sizedBox = const SizedBox(
      height: 10,
    );
    return Scaffold(
      appBar: AppBar(
        title: const Text('কর্মকর্তা/কর্মচারী হালনাগাদ করুন'),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 15.0, right: 15.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                sizedBox,
                sizedBox,
                MyAuthFormField(
                  labelText: 'ব্যবহারকারীর নাম',
                  hinText: 'ব্যবহারকারীর নাম',
                  controller: controller.name,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'ব্যবহারকারীর নাম দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                MyAuthFormField(
                  labelText: 'মোবাইল',
                  hinText: '01700000000',
                  controller: controller.mobile,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'মোবাইল নম্বর দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                MyAuthFormField(
                  labelText: 'ইমেইল',
                  hinText: 'xxx@mail.com',
                  controller: controller.email,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'ইমেইল দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                MyAuthFormField(
                  labelText: 'পাসওয়ার্ড',
                  hinText: '********',
                  obscureText: true,
                  maxLines: 1,
                  controller: controller.newPassword,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'পাসওয়ার্ড দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                MyAuthFormField(
                  labelText: 'পদবি',
                  hinText: 'পদবি',
                  controller: controller.designation,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'পদবি দিন';
                    }
                    return null;
                  },
                ),
                sizedBox,
                const Text(
                  'শাখা',
                  style: TextStyle(),
                ),
                Obx(() {
                  return Container(
                      height: 40,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5.0),
                        border: Border.all(
                            color: controller.selectedBranch.value == null &&
                                    controller.dropdownValidator.value == true
                                ? Colors.red
                                : Colors.grey),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 18.0, right: 18.0),
                        child: Center(
                          child: DropdownButtonHideUnderline(
                              child: DropdownButton<Branch>(
                                  isExpanded: true,
                                  alignment: Alignment.center,
                                  value: controller.selectedBranch.value,
                                  icon: const Icon(
                                    Icons.keyboard_arrow_down,
                                    color: AppTheme.primaryColorConst,
                                    size: 30,
                                  ),
                                  elevation: 16,
                                  style: TextStyle(
                                      fontSize: 13, color: Colors.grey[800]),
                                  onChanged: (Branch? newValue) {
                                    controller.selectedBranch.value = newValue!;
                                    controller.dropdownValidator.value = false;
                                  },
                                  hint: const Text(
                                    "নির্বাচন করুণ",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.grey),
                                  ),
                                  items: Branch.branchList.map((e) {
                                    return DropdownMenuItem<Branch>(
                                      value: e,
                                      child: Text(e.name),
                                    );
                                  }).toList())),
                        ),
                      ));
                }),
                sizedBox,
                sizedBox,
                sizedBox,
                sizedBox,
                sizedBox,
                InkWell(
                  onTap: () async {
                    controller.dropdownValidator.value = true;
                    if (_formKey.currentState != null &&
                        _formKey.currentState!.validate() &&
                        controller.selectedBranch.value != null) {
                      controller.dropdownValidator.value = false;
                      await controller.updateData();
                      Get.back();
                    }
                  },
                  child: Center(
                    child: Container(
                        height: 35,
                        width: 220,
                        decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Text(
                              'কর্মকর্তা/কর্মচারী হালনাগাদ করুন',
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        )),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
