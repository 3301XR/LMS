# Widgets

Separated view elements of the module.