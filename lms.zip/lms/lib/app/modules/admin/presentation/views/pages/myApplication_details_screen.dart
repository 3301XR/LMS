import 'package:flutter/material.dart';

class MyApplicationDetailsScreen extends StatelessWidget {
  final String? startLeave;
  final String? endLeave;
  final String? applicationDate;
  final String? totalLeave;
  final String? approvedLeave;
  final String? stay;
  final String? reason;
  final String? comment;
  final String? returnn;
  final String? approved;

  const MyApplicationDetailsScreen(
      {Key? key,
      this.applicationDate,
      this.approvedLeave,
      this.comment,
      this.endLeave,
      this.reason,
      this.startLeave,
      this.stay,
      this.returnn,
      this.approved,
      this.totalLeave})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    var sizedBox = const SizedBox(
      height: 20,
    );
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'বিস্তারিত তথ্য',
          // style: TextStyle(color: AppTheme.primaryFontColo),
        ),
        elevation: 0,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          sizedBox,
          Padding(
            padding: const EdgeInsets.only(left: 15.0, right: 15.0),
            child: Column(
              children: [
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'আবেদনের তারিখ:',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        applicationDate.toString(),
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'ছুটির মেয়াদকাল শুরু: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        startLeave.toString(),
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'ছুটির মেয়াদকাল শেষ: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        endLeave.toString(),
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'আবেদনকৃত ছুটি: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        '$totalLeave দিন',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'অনুমোদিত ছুটি: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        '$approvedLeave দিন',
                        style: const TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'অবস্থান: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        stay.toString(),
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'কারন: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        reason.toString(),
                        style: const TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'মন্তব্য: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: Text(
                        comment == null ? "" : comment.toString(),
                        style: const TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.25,
                      child: const Text(
                        'বর্তমান অবস্থা: ',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      width: width * 0.6,
                      child: approved == "1"
                          ? const Text(
                              ' অনুমোদিত',
                              overflow: TextOverflow.ellipsis,
                              style:
                                  TextStyle(fontSize: 18, color: Colors.green),
                            )
                          : approved == "0"
                              ? const Text(
                                  ' প্রত্যাখ্যাত',
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 18, color: Colors.red),
                                )
                              : Text(
                                  ' অপেক্ষমাণ..',
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 18, color: Colors.green[300]),
                                ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
