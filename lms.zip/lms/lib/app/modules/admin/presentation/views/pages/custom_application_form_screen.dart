import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../view_models/custom_application_controller.dart';
import '../widgets/auth_field_widget.dart';

class CustomApplicationFromScreen extends StatelessWidget {
  final int id;
  final String comment;
  final String start;
  final String end;
  final String? days;
  CustomApplicationFromScreen(
      {Key? key,
      required this.id,
      required this.comment,
      required this.start,
      required this.end,
      this.days})
      : super(key: key) {
    controller = Get.put(CustomApplicationForSuperAdminController(
        days: days, comment: comment, end: end, start: start, id: id));
  }
  late final CustomApplicationForSuperAdminController controller;

  @override
  Widget build(BuildContext context) {
    var sizedBox = const SizedBox(height: 15);
    return Scaffold(
      appBar: AppBar(
        title: const Text("সংশোধন"),
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 15.0, right: 15.0, top: 15),
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(5)),
              height: 45,
              width: MediaQuery.of(context).size.width,
              child: Padding(
                padding: const EdgeInsets.only(left: 25.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$days  দিন',
                    ),
                  ],
                ),
              ),
            ),
            MyAuthFormField(
              controller: controller.startDateController,
              readOnly: true,
              hinText: 'mm/dd/yy',
              labelText: 'হতে:',
              onTap: () {
                showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(1900),
                  lastDate: DateTime(2050),
                ).then((value) async {
                  if (value != null) {
                    controller.startDateController.text =
                        DateFormat('yyyy-MM-dd').format(value);
                  }
                });
              },
            ),
            sizedBox,
            MyAuthFormField(
              controller: controller.toDateController,
              readOnly: true,
              hinText: 'mm/dd/yy',
              labelText: 'হতে:',
              onTap: () {
                showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(1900),
                  lastDate: DateTime(2050),
                ).then((value) async {
                  if (value != null) {
                    controller.toDateController.text =
                        DateFormat('yyyy-MM-dd').format(value);
                  }
                });
              },
            ),
            sizedBox,
            MyAuthFormField(
              maxLines: 4,
              controller: controller.commentController,
              readOnly: false,
              hinText: 'মন্তব্য',
              labelText: 'মন্তব্য:',
            ),
            sizedBox,
            InkWell(
              onTap: () async {
                await controller.getCustomApplication(
                    id,
                    controller.commentController.text,
                    controller.startDateController.text,
                    controller.toDateController.text);
              },
              child: Container(
                height: 30,
                width: 80,
                decoration: BoxDecoration(color: Colors.green[300]),
                child: const Center(
                  child: Text(
                    ' দাখিল',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
