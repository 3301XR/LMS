import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/modules/admin/presentation/view_models/pending_application_controller.dart';
import 'package:lms/app/modules/admin/presentation/views/pages/custom_application_form_screen.dart';

class PendingApplicationList extends StatelessWidget {
  PendingApplicationList({Key? key}) : super(key: key) {
    controller = Get.put(PendingApplicationForSuperAdminController());
  }

  late PendingApplicationForSuperAdminController controller;

  // MyApplicationVM myApplicationVM = Get.put(MyApplicationVM());

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text('অপেক্ষামান তালিকা'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      onChanged: (v) {
                        controller.onSearch(v);
                      },
                      decoration: InputDecoration(
                          contentPadding: const EdgeInsets.only(left: 20),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5),
                              borderSide: const BorderSide(
                                color: Colors.grey,
                              )),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5),
                              borderSide: const BorderSide(
                                color: Colors.grey,
                              )),
                          hintText: "Search"),
                    ),
                  ),
                ),
              ],
            ),
            Padding(
                padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                child: Obx(() {
                  return ListView.builder(
                    shrinkWrap: true,
                    itemCount: controller.applicationList.length,
                    itemBuilder: (context, index) {
                      controller.isHealthExpanded.add(false);
                      return Column(
                        children: [
                          Container(
                            margin: const EdgeInsets.all(5),
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.5),
                                  spreadRadius: 1,
                                  blurRadius: 1,
                                  offset: const Offset(
                                      1, 1), // changes position of shadow
                                ),
                              ],
                              color: Colors.white,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                InkWell(
                                  onTap: () {
                                    controller.isHealthExpanded[index] =
                                        !controller.isHealthExpanded[index];
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(5),
                                    child: Container(
                                        height: 30,
                                        width: 30,
                                        decoration: BoxDecoration(
                                            color: Colors.blue,
                                            borderRadius:
                                                BorderRadius.circular(30)),
                                        child: const Icon(
                                          Icons.add,
                                          color: Colors.white,
                                        )),
                                  ),
                                ),
                                Expanded(
                                  child: SizedBox(
                                      width: width * 0.75,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            controller.applicationList[index]
                                                    .name ??
                                                "",
                                            style:
                                                const TextStyle(fontSize: 12),
                                          ),
                                          Text(
                                            controller.applicationList[index]
                                                    .department ??
                                                "",
                                            style:
                                                const TextStyle(fontSize: 12),
                                          ),
                                        ],
                                      )),
                                )
                              ],
                            ),
                          ),
                          Obx(() => controller.isHealthExpanded[index]
                              ? Container(
                                  width: width,
                                  margin: const EdgeInsets.only(
                                      top: 10, bottom: 10, left: 10, right: 10),
                                  decoration:
                                      const BoxDecoration(color: Colors.white),
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          const Text(
                                            'মেয়াদকাল শুরু ',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 12),
                                          ),
                                          Flexible(
                                            child: Text(
                                              controller.applicationList[index]
                                                      .start ??
                                                  "",
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(fontSize: 12),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          const Text(
                                            'মেয়াদকাল শেষ ',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 12),
                                          ),
                                          Flexible(
                                            child: Text(
                                              controller.applicationList[index]
                                                      .end ??
                                                  "",
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(fontSize: 12),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          const Text(
                                            'আবেদনকৃত ছুটি ',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 12),
                                          ),
                                          Flexible(
                                            child: Text(
                                              controller.applicationList[index]
                                                  .totalDays
                                                  .toString(),
                                              overflow: TextOverflow.ellipsis,
                                              style:
                                                  const TextStyle(fontSize: 12),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          const Text(
                                            'কারণ ',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 12),
                                          ),
                                          Flexible(
                                            child: Text(
                                              controller.applicationList[index]
                                                      .reason ??
                                                  "",
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(fontSize: 12),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          const Text(
                                            'ছুটিকালীন অবস্থান ',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 12),
                                          ),
                                          Flexible(
                                            child: Text(
                                              controller.applicationList[index]
                                                      .stay ??
                                                  "",
                                              overflow: TextOverflow.ellipsis,
                                              style:
                                                  const TextStyle(fontSize: 12),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          const Text(
                                            'আবেদনের তারিখ ',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 12),
                                          ),
                                          Flexible(
                                            child: Text(
                                              controller.applicationList[index]
                                                      .createdAt ??
                                                  "",
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(fontSize: 12),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Text(
                                            'ভোগকৃত ছুটি ',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 12),
                                          ),
                                          Flexible(
                                            child: Obx(() {
                                              return Text(
                                                ' ${controller.applicationList[index].totalDays ?? ''} দিন',
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(fontSize: 12),
                                              );
                                            }),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          const Text(
                                            'অবশিষ্ট ছুটি ',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 12),
                                          ),
                                          Flexible(
                                            child: Text(
                                              '${controller.applicationList[index].total ?? ""}  দিন',
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(fontSize: 12),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          InkWell(
                                            onTap: () {
                                              showApprovedPopup(
                                                  context,
                                                  controller
                                                      .applicationList[index]
                                                      .id!);
                                            },
                                            child: Container(
                                              height: 30,
                                              width: 80,
                                              decoration: const BoxDecoration(
                                                  color: Colors.green),
                                              child: const Center(
                                                child: Text(
                                                  'অনুমোদন',
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(
                                            width: 20,
                                          ),
                                          InkWell(
                                            onTap: () {
                                              Get.to(() =>
                                                  CustomApplicationFromScreen(
                                                    days: controller
                                                        .applicationList[index]
                                                        .totalDays
                                                        .toString(),
                                                    id: controller
                                                        .applicationList[index]
                                                        .id!,
                                                    comment: controller
                                                        .applicationList[index]
                                                        .comment
                                                        .toString(),
                                                    end: controller
                                                        .applicationList[index]
                                                        .end
                                                        .toString(),
                                                    start: controller
                                                        .applicationList[index]
                                                        .start
                                                        .toString(),
                                                  ));
                                            },
                                            child: Container(
                                              height: 30,
                                              width: 80,
                                              decoration: BoxDecoration(
                                                  color: Colors.green[300]),
                                              child: const Center(
                                                child: Text(
                                                  'সংশোধন',
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(
                                            width: 20,
                                          ),
                                          InkWell(
                                            onTap: () {
                                              showDeletePopup(
                                                  context,
                                                  controller
                                                      .applicationList[index]
                                                      .id!);
                                            },
                                            child: Container(
                                              height: 30,
                                              width: 80,
                                              decoration: const BoxDecoration(
                                                  color: Colors.red),
                                              child: const Center(
                                                child: Text(
                                                  'বাতিল',
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ))
                              : const SizedBox())
                        ],
                      );
                    },
                  );
                })),
          ],
        ),
      ),
    );
  }

  showDeletePopup(BuildContext context, int id) {
    // set up the button
    Widget okButton = Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        InkWell(
          onTap: () {
            Get.back();
          },
          child: const Padding(
            padding: EdgeInsets.all(15),
            child: Text('বাতিল'),
          ),
        ),
        InkWell(
          onTap: () async {
            await controller.applicationRejected(id);
            Get.back();
          },
          child: const Padding(
            padding: EdgeInsets.all(15),
            child: Text('কনফার্ম'),
          ),
        )
      ],
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("আপনি বাতিল করতে চান"),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  showApprovedPopup(BuildContext context, int id) {
    // set up the button
    Widget okButton = Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        InkWell(
          onTap: () {
            Get.back();
          },
          child: const Padding(
            padding: EdgeInsets.all(15),
            child: Text('বাতিল'),
          ),
        ),
        InkWell(
          onTap: () {
            controller.applicationReturn(id);
            Get.back();
          },
          child: const Padding(
            padding: EdgeInsets.all(15),
            child: Text('অনুমদন'),
          ),
        )
      ],
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("আপনি অনুমদন করতে চান"),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
