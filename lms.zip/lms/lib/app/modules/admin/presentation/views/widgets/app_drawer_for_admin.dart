import 'package:flutter/material.dart';

import 'admin_drawer_widget.dart';

class AppDrawerForAdmin extends StatelessWidget {
  const AppDrawerForAdmin({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [AdminDrawerWidget()],
      ),
    );
  }
}

class DrawerListWidget extends StatelessWidget {
  // final IconData icon;
  final String image;
  final IconData? iconTrailing;
  final String label;
  final Color? colorLabel;
  final bool isSelected;
  final Function onTap;
  final Color? color;
  final Key? key;

  const DrawerListWidget({
    // required this.icon,
    required this.label,
    this.color,
    this.colorLabel,
    required this.image,
    this.iconTrailing,
    this.isSelected = false,
    required this.onTap,
    this.key,
  });

  @override
  Widget build(BuildContext context) {
    // var isMobile = Responsive.isMobile(context);
    return Material(
      color: isSelected
          ? Theme.of(context).scaffoldBackgroundColor
          : Colors.transparent,
      child: Row(
        children: <Widget>[
          Container(
            color: isSelected
                ? const Color(0xff93c83d)
                : Theme.of(context).scaffoldBackgroundColor,
            width: 4,
            height: AppBar().preferredSize.height,
          ),
          Expanded(
            child: ListTile(
              onTap: onTap as void Function()?,
              title: Text(
                label,
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: colorLabel),
              ),
              trailing: Icon(
                iconTrailing,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
