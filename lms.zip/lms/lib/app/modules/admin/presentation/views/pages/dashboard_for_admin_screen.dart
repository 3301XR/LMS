import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/shared/widgets/common_title_widget.dart';

import '../../../../../shared/widgets/common_card_widget.dart';
import '../../../../admin/presentation/views/widgets/app_drawer_for_admin.dart';
import '../../../../super_admin/presentation/views/pages/join_list_screen.dart';
import '../../view_models/dashboard_for_admin.dart';
import 'application_form_for_admin_screen.dart';
import 'pending_application_list.dart';

class DashboardForAdminScreen extends StatelessWidget {
  DashboardForAdminScreen({Key? key}) : super(key: key) {
    controller = Get.put(DashboardForAdminController());
  }

  late final DashboardForAdminController controller;

  @override
  Widget build(BuildContext context) {
    var sizedBox = const SizedBox(
      height: 20,
    );
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'ড্যাশবোর্ড',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
        actions: [
          // IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          Padding(
            padding: const EdgeInsets.only(right: 20.0),
            child: SizedBox(
              width: 50,
              child: Stack(alignment: Alignment.center, children: [
                InkWell(
                    onTap: () {
                      Get.to(() => PendingApplicationList());
                    },
                    child: const Icon(Icons.notifications)),
                Positioned(
                  left: 30,
                  top: 10,
                  child: Container(
                    height: 14,
                    width: 14,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Obx(() {
                      return Center(
                        child: Text(
                          "${controller.pendingApplicationList.length}",
                          style: const TextStyle(color: Colors.white),
                        ),
                      );
                    }),
                  ),
                )
              ]),
            ),
          ),
        ],
      ),
      drawer: const Drawer(
        child: AppDrawerForAdmin(),
      ),
      body: Obx(() => controller.dashboardResponse.value == null
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.only(left: 15.0, right: 15.0),
                child: Column(
                  children: [
                    sizedBox,
                    Obx(() {
                      return controller.dashboardResponse.value == null
                          ? Container()
                          : CommonTitleWidget(
                              height: height * 0.1,
                              title:
                                  'স্বাগতম ${controller.dashboardResponse.value?.user?.username ?? ""} !',
                            );
                    }),
                    sizedBox,
                    CommonTitleWidget(
                      height: height * 0.1,
                      title: 'দাপ্তরিক',
                    ),
                    sizedBox,
                    Obx(() {
                      return controller.dashboardResponse.value == null
                          ? Container()
                          : CommonCardWidget(
                              icon: Icons.person_outline_sharp,
                              title: 'ছুটিতে',
                              dataInfo:
                                  '${controller.dashboardResponse.value?.applications ?? "0"} জন',
                              height: height * 0.15,
                              width: width,
                              onTap: () {
                                controller.onLeaveInfo();
                              },
                            );
                    }),
                    sizedBox,
                    Obx(() {
                      return controller.dashboardResponse.value == null
                          ? Container()
                          : CommonCardWidget(
                              icon: Icons.person_outline_sharp,
                              title: 'কর্মরত',
                              dataInfo:
                                  '${controller.dashboardResponse.value?.join ?? ""} জন',
                              height: height * 0.15,
                              width: width,
                              onTap: () {
                                Get.to(() => JoinListScreen());
                              },
                            );
                    }),
                    sizedBox,
                    CommonTitleWidget(
                      height: height * 0.1,
                      title: 'ব্যক্তিগত',
                    ),
                    sizedBox,
                    Obx(() {
                      return controller.dashboardResponse.value == null
                          ? Container()
                          : CommonCardWidget(
                              icon: Icons.person_outline_sharp,
                              title: 'ভোগকৃত ছুটি',
                              dataInfo:
                                  '${controller.dashboardResponse.value?.leaveTaken ?? ''} দিন',
                              height: height * 0.15,
                              width: width,
                            );
                    }),
                    sizedBox,
                    Obx(() {
                      return controller.dashboardResponse.value == null
                          ? Container()
                          : CommonCardWidget(
                              icon: Icons.person_outline_sharp,
                              title: 'অবশিষ্ট ছুটি',
                              dataInfo:
                                  '${controller.dashboardResponse.value?.remaingLeave ?? ""} দিন',
                              height: height * 0.15,
                              width: width,
                            );
                    }),
                    sizedBox,
                    InkWell(
                      child: CommonTitleWidget(
                        height: height * 0.1,
                        title: 'জমাকৃত আবেদন',
                      ),
                      onTap: () {
                        Get.to(() => PendingApplicationList());
                      },
                    ),
                    sizedBox,
                    InkWell(
                      onTap: () {
                        Get.to(() => ApplicationFromForAdminScreen());
                      },
                      child: CommonTitleWidget(
                        height: height * 0.1,
                        title: 'আবেদন',
                      ),
                    ),
                    sizedBox,
                  ],
                ),
              ),
            )),
    );
  }
}
