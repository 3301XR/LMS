# Views

Responsible for rendering the application's views.