# Template Module

A module is a distinguishable feature of an app. 
Usually separated by the bounded context. Can be compared to a microservice.