import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;
import 'package:lms/app/modules/admin/models/application_return_check_by_is_response.dart';
import 'package:lms/app/modules/admin/models/join_list_response.dart';
import 'package:lms/app/modules/admin/models/responses/application_custom_response.dart';
import 'package:lms/app/modules/admin/models/responses/operator_dashboard_response.dart';
import 'package:lms/app/modules/auth/models/requests/create_update_user_request.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/models/responses/application_list_response.dart';
import 'package:lms/app/modules/employee/models/responses/application_return_response.dart';
import 'package:lms/app/shared/errors/failures.dart';

import '../../employee/models/requests/save_application_request.dart';
import '../../employee/models/responses/send_application_response.dart';
import '../models/responses/admin_profile_response.dart';
import '../models/responses/edit_admin_response.dart';
import '../models/responses/employee_list_response.dart';
import '../models/responses/employee_update_response.dart';
import '../models/responses/operator_dashboard_response.dart';
import '../models/responses/operator_edit_response.dart';
import '../models/responses/operator_list_response.dart';
import '../models/responses/profile_details_response.dart';

import '../models/responses/generic_response.dart';

abstract class AdminRepository {
  Future<Either<Failure, AdminProfileResponse>> getOperatorProfile();

  Future<Either<Failure, DashboardResponse>> getOperatorDashboard();

  Future<Either<Failure, GenericResponse>> createOperator(
      CreateUpdateUserRequest createUserRequest);

  Future<Either<Failure, ApplicationListResponse>> pendingApplication();

  Future<Either<Failure, ApplicationListResponse>> getApplicationList(int id);

  Future<Either<Failure, GenericResponse>> adminApplicationStore(
      SaveApplicationRequest saveApplicationRequest);

  Future<Either<Failure, GetEditAdminResponse>> getAdminEdit(int id);

  Future<Either<Failure, OperatorListResponse>> getOperatorList();

  Future<Either<Failure, GenericResponse>> getOperatorDelete(int id);

  Future<Either<Failure, OperatorEditResponse>> getOperatorEdit(int id);

  Future<Either<Failure, OperatorEditResponse>> operatorUpdate(
      int id, CreateUpdateUserRequest createUpdateUserRequest);

  Future<Either<Failure, ProfileDetailsResponse>> getOperatorProfileDetails(
      int id);

  Future<Either<Failure, GenericResponse>> createEmployee(
      CreateUpdateUserRequest createUpdateUserRequest);

  Future<Either<Failure, GenericResponse>> adminEdit(
      int id, CreateUpdateUserRequest createUpdateUserRequest);

  Future<Either<Failure, EmployeeListResponse>> getEmployeeList();

  Future<Either<Failure, GenericResponse>> deleteEmployee(int id);

  Future<Either<Failure, EmployeeUpdateResponse>> getEmployeeEdit(int id);

  Future<Either<Failure, EmployeeUpdateResponse>> employeeUpdate(
      int id, CreateUpdateUserRequest createUpdateUserRequest);

  Future<Either<Failure, ProfileDetailsResponse>> getEmployeeDetails(int id);

  Future<Either<Failure, ApplicationListResponse>> getPendingLeaveApplication();

  Future<Either<Failure, AdminProfileResponse>> getAdminProfile();

  Future<Either<Failure, SendApplicationResponse>> geSendApplication();

  Future<Either<Failure, ApplicationCustomResponse>> getApplicationCustom(
      int id, String? comment, String? start, String? end);

  Future<Either<Failure, ApplicationReturnResponse>> geRejectedApplication(
      int id);

  Future<Either<Failure, ApplicationReturnResponse>> geConfirmApplication(
      int id);

  Future<Either<Failure, ApplicationReturnCheckByIdResponse>>
      getApplicationReturnCheck(int id);

  Future<Either<Failure, JoinListResponse>> getApplicationJoinList();

  Future<Either<Failure, ApplicationListResponse>> getLeaveList();

  Future<Either<Failure, ApplicationReturnResponse>>
      getApplicationReturnDetails(int id);

  Future<Either<Failure, ApplicationReturnResponse>> getApprovedApplication(
      int id);
}

class AdminRepositoryImpl implements AdminRepository {
  final AuthRepository _authRepository;

  AdminRepositoryImpl(this._authRepository);

  @override
  Future<Either<Failure, AdminProfileResponse>> getOperatorProfile() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/operator'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      return Right(AdminProfileResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, GenericResponse>> createOperator(
      CreateUpdateUserRequest createUserRequest) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'POST', Uri.parse('https://factanalyzer.com/api/create/oparetor'));
    request.fields.addAll(createUserRequest
        .toMap()
        .map((key, value) => MapEntry(key, value.toString())));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(
          GenericResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, DashboardResponse>> getOperatorDashboard() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/oparetor'));
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(
          DashboardResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationListResponse>> pendingApplication() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/pending/application'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationListResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationListResponse>> getApplicationList(
      int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.Request('GET',
        Uri.parse('https://factanalyzer.com/api/admin/application/list/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationListResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, GenericResponse>> adminApplicationStore(
      SaveApplicationRequest saveApplicationRequest) async {
    print("Req: ${saveApplicationRequest.toJson()}");
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'POST', Uri.parse('https://factanalyzer.com/api/application/store'));
    request.fields.addAll(saveApplicationRequest
        .toJson()
        .map((key, value) => MapEntry(key, value.toString())));
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
    // print("Res: ${await response.stream.bytesToString()}");

    if (response.statusCode == 200) {
      return Right(
          GenericResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, GetEditAdminResponse>> getAdminEdit(int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.Request(
        'GET', Uri.parse('https://factanalyzer.com/api/user/edit/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(GetEditAdminResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, OperatorListResponse>> getOperatorList() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/Admin/oparetorlist'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      return Right(OperatorListResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, GenericResponse>> getOperatorDelete(int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/oparetor/delete/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(
          GenericResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, OperatorEditResponse>> getOperatorEdit(int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/oparetor/edit/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(OperatorEditResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, OperatorEditResponse>> operatorUpdate(
      int id, CreateUpdateUserRequest createUpdateUserRequest) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'POST', Uri.parse('https://factanalyzer.com/api/oparetor/edit/$id'));
    request.fields.addAll(createUpdateUserRequest
        .toMap()
        .map((key, value) => MapEntry(key, value.toString())));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(OperatorEditResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ProfileDetailsResponse>> getOperatorProfileDetails(
      int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest('GET',
        Uri.parse('https://factanalyzer.com/api/oparetor/profile/details/$id'));
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ProfileDetailsResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, GenericResponse>> createEmployee(
      CreateUpdateUserRequest createUpdateUserRequest) async {
    print(createUpdateUserRequest.toJson());
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'POST', Uri.parse('https://factanalyzer.com/api/create/employee'));

    request.fields.addAll(createUpdateUserRequest
        .toMap()
        .map((key, value) => MapEntry(key, value.toString())));
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(
          GenericResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, GenericResponse>> adminEdit(
      int id, CreateUpdateUserRequest createUpdateUserRequest) async {
    print(id);
    print(createUpdateUserRequest.toJson());
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'POST', Uri.parse('https://factanalyzer.com/api/admin/edit/$id'));

    request.fields.addAll(createUpdateUserRequest
        .toMap()
        .map((key, value) => MapEntry(key, value.toString())));
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(
          GenericResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, EmployeeListResponse>> getEmployeeList() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.Request(
        'GET', Uri.parse('https://factanalyzer.com/api/Admin/employeelist'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(
          EmployeeListResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, GenericResponse>> deleteEmployee(int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/employee/delete/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(
          GenericResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, EmployeeUpdateResponse>> getEmployeeEdit(
      int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/emp/edit/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(EmployeeUpdateResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, EmployeeUpdateResponse>> employeeUpdate(
      int id, CreateUpdateUserRequest createUpdateUserRequest) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'POST', Uri.parse('https://factanalyzer.com/api/emp/edit/$id'));
    request.fields.addAll(createUpdateUserRequest
        .toMap()
        .map((key, value) => MapEntry(key, value.toString())));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(EmployeeUpdateResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ProfileDetailsResponse>> getEmployeeDetails(
      int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest('GET',
        Uri.parse('https://factanalyzer.com/api/employee/profile/details/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      return Right(ProfileDetailsResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationListResponse>>
      getPendingLeaveApplication() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest('GET',
        Uri.parse('https://factanalyzer.com/api/pending/leave/application'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationListResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, AdminProfileResponse>> getAdminProfile() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/admin/profile'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(AdminProfileResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, SendApplicationResponse>> geSendApplication() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest('GET',
        Uri.parse('https://factanalyzer.com/api/admin/send/application'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(SendApplicationResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationCustomResponse>> getApplicationCustom(
      int id, String? comment, String? start, String? end) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest(
        'POST', Uri.parse('https://factanalyzer.com/api/approve/$id'));
    request.fields
        .addAll({'comment': '$comment', 'start': '$start', 'end': '$end'});

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationCustomResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationReturnResponse>> geRejectedApplication(
      int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/confirm/reject/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationReturnResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationReturnResponse>> geConfirmApplication(
      int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.MultipartRequest(
        'GET', Uri.parse('https://factanalyzer.com/api/confirm/approve/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationReturnResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationReturnCheckByIdResponse>>
      getApplicationReturnCheck(int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.Request('GET',
        Uri.parse('https://factanalyzer.com/api/application/return/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationReturnCheckByIdResponse.fromRawJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, JoinListResponse>> getApplicationJoinList() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.Request(
        'GET', Uri.parse('https://factanalyzer.com/api/join/list'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(
          JoinListResponse.fromJson(await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationListResponse>> getLeaveList() async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.Request(
        'GET', Uri.parse('https://factanalyzer.com/api/leave/list'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationListResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationReturnResponse>>
      getApplicationReturnDetails(int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.Request(
        'GET',
        Uri.parse(
            'https://factanalyzer.com/api/application/return/Details/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationReturnResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, ApplicationReturnResponse>> getApprovedApplication(
      int id) async {
    final loginResponse = await _authRepository.getLoginResponse();
    String? token;

    loginResponse.fold((l) => left(l), (r) => token = r.token);

    if (token == null) {
      return const Left(AuthFailure());
    }

    var headers = {
      'Authorization': 'Bearer $token',
    };

    var request = http.Request('GET',
        Uri.parse('https://factanalyzer.com/api/application/approve/$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      return Right(ApplicationReturnResponse.fromJson(
          await response.stream.bytesToString()));
    } else {
      return Left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }
}
