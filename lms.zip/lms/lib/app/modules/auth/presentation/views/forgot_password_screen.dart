import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../shared/values/colors.dart';
import '../../../admin/presentation/view_models/forgot_pass_vm.dart';
import '../../../admin/presentation/views/widgets/auth_field_widget.dart';

class ForgotPasswordScreen extends GetView<ForgotPasswordController> {
  ForgotPasswordScreen({Key? key}) : super(key: key);
  final ForgotPasswordController authController =
      Get.put(ForgotPasswordController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: [BoxShadow(color: Colors.white)]),
            child: Padding(
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 150,
                    child: Stack(
                      children: [
                        Positioned(
                          top: 0,
                          left: 0,
                          child: Container(
                              decoration:
                                  const BoxDecoration(color: Color(0XFFD4DBF9)),
                              height: 80,
                              width: MediaQuery.of(context).size.width,
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(left: 0, right: 0),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: const [
                                        Text('নৈমিত্তিক ছুটি ব্যবস্থাপনায়'),
                                        Text('আপনাকে স্বাগতম!'),
                                      ],
                                    ),
                                    Image.asset(
                                      'assets/profile-img.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ],
                                ),
                              )),
                        ),
                        Positioned(
                            bottom: 10,
                            left: 20,
                            child: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0XFFEFF2F7),
                                  borderRadius: BorderRadius.circular(100),
                                ),
                                height: 80,
                                child: ClipRRect(
                                    borderRadius: BorderRadius.circular(20),
                                    child: Image.asset('assets/log.png')))),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 0, right: 0),
                    child: Column(
                      children: [
                        MyAuthFormField(
                          onSaved: (v) {
                            controller.email.value = v;
                          },
                          labelText: 'ইমেইল/মোবাইল নাম্বার',
                          hinText: 'Enter Email',
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Obx(() {
                          return Container(
                            height: 40,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(5.0),
                              border:
                                  Border.all(color: const Color(0XFFE2E2E2)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 18.0, right: 18.0),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                    value: controller.role.value,
                                    icon: const Icon(
                                      Icons.keyboard_arrow_down,
                                      color: AppTheme.primaryColorConst,
                                      size: 30,
                                    ),
                                    elevation: 16,
                                    style: TextStyle(
                                        fontSize: 13, color: Colors.grey[800]),
                                    onChanged: (String? newValue) {
                                      controller.role.value = newValue!;
                                    },
                                    hint: const Text(
                                      "Role",
                                      style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.grey),
                                    ),
                                    items: ['Admin', 'Employee'].map((e) {
                                      return DropdownMenuItem<String>(
                                        value: e,
                                        child: Text(e),
                                      );
                                    }).toList()),
                              ),
                            ),
                          );
                        }),
                        const SizedBox(
                          height: 20,
                        ),
                        // স্মরণ রাখুন\ অ্যাকাউন্ট টি পুনরুদ্ধার করুণ

                        InkWell(
                          onTap: () {
                            controller.onSendCode();
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                color: const Color(0XFF4862E4),
                                borderRadius: BorderRadius.circular(5)),
                            height: 40,
                            width: MediaQuery.of(context).size.width,
                            child: const Center(
                              child: Text(
                                'Send Code',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Row(
                          children: [
                            const Text('Already h ave an account?'),
                            InkWell(
                              onTap: () {
                                Get.back();
                              },
                              child: Text(
                                'Login',
                                style: TextStyle(
                                    color: AppTheme.primaryColor,
                                    fontWeight: FontWeight.w600),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
