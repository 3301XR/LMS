import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../admin/presentation/views/widgets/auth_field_widget.dart';
import '../controllers/login_controller.dart';
import 'forgot_password_screen.dart';

class LoginScreen extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();

  LoginScreen({Key? key}) : super(key: key) {
    controller = Get.put(LoginController());
  }

  late final LoginController controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Form(
        key: _formKey,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            Container(
              decoration: const BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.white)]),
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 150,
                      child: Stack(
                        children: [
                          Positioned(
                            top: 0,
                            left: 0,
                            child: Container(
                                decoration: const BoxDecoration(
                                    color: Color(0XFFD4DBF9)),
                                height: 80,
                                width: MediaQuery.of(context).size.width,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.only(left: 0, right: 0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: const [
                                            Text('নৈমিত্তিক ছুটি ব্যবস্থাপনায়'),
                                            Text('আপনাকে স্বাগতম!'),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Image.asset(
                                          'assets/profile-img.png',
                                          fit: BoxFit.contain,
                                        ),
                                      ),
                                    ],
                                  ),
                                )),
                          ),
                          Positioned(
                              bottom: 10,
                              left: 20,
                              child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(0XFFEFF2F7),
                                    borderRadius: BorderRadius.circular(100),
                                  ),
                                  height: 80,
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Image.asset('assets/log.png')))),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 0, right: 0),
                      child: Column(
                        children: [
                          MyAuthFormField(
                            // onSaved: (v) {
                            //   controller.email.value = v!;
                            // },
                            controller: controller.email,
                            labelText: 'ইমেইল/মোবাইল নাম্বার',
                            hinText: 'Enter Email',
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          MyAuthFormField(
                            controller: controller.password,
                            // onSaved: (v) {
                            //   controller.password.value = v!;
                            // },
                            labelText: 'পাসওয়ার্ড',
                            obscureText: true,
                            maxLines: 1,
                            hinText: 'Enter Password',
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          // স্মরণ রাখুন\ অ্যাকাউন্ট টি পুনরুদ্ধার করুণ

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Obx(() {
                                    return Checkbox(
                                      value: controller.remember.value,
                                      onChanged: (bool? value) {
                                        controller.remember.value = value!;
                                        print(controller.remember.value);
                                      },
                                    );
                                  }), //C
                                  const Text('স্মরণ রাখুন'),
                                ],
                              ),
                              InkWell(
                                  onTap: () async {
                                    // Get.to(() => ForgotPasswordScreen());
                                    await controller.onClickRecoverAccount();
                                  },
                                  child: const Text(
                                      'অ্যাকাউন্টটি পুনরুদ্ধার করুণ')),
                            ],
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          InkWell(
                            onTap: () async {
                              if (_formKey.currentState!.validate()) {
                                _formKey.currentState!.save();
                                await controller.onLogin();
                              }
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                  color: const Color(0XFF4862E4),
                                  borderRadius: BorderRadius.circular(5)),
                              height: 40,
                              width: MediaQuery.of(context).size.width,
                              child: const Center(
                                child: Text(
                                  'প্রবেশ করুন',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 32,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "© ${DateTime.now().year} নৈমিত্তিক ছুটি ব্যবস্থাপনা",
                            style: TextStyle(
                              color: Colors.black.withOpacity(0.30),
                            ),
                          ),
                          const SizedBox(
                            height: 14,
                          ),
                          Text(
                            "সহযোগীতায়:",
                            style: TextStyle(
                              color: Colors.black.withOpacity(0.30),
                            ),
                          ),
                          TextButton(
                            style: TextButton.styleFrom(
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                              primary: Colors.teal.withOpacity(0.75),
                            ),
                            onPressed: () async {
                              await controller.onClickBrand();
                            },
                            child: const Text(
                              "Tradewave Technology",
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
