import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/modules/admin/presentation/views/pages/dashboard_for_admin_screen.dart';
import 'package:lms/app/modules/auth/models/requests/login_request.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/presentation/views/pages/dashboard_for_user_screen.dart';
import 'package:lms/app/modules/super_admin/presentation/views/pages/dashboard_for_super_admin_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class LoginController extends GetxController {
  // final email = "".obs;
  final email = TextEditingController();
  final password = TextEditingController();
  // final password = "".obs;
  var rememberEmail = "".obs;
  var rememberPassword = "".obs;

  var remember = false.obs;
  final AuthRepository _authRepository = Get.find();

  Future<void> getRememberMeUser() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    rememberEmail.value = prefs.getString("emailRemember") ?? "";

    rememberPassword.value = prefs.getString("passwordRemember") ?? "";
    var rememberMe = prefs.getBool("value") ?? false;

    if (rememberMe == true) {
      email.text = rememberEmail.value;

      password.text = rememberPassword.value;
    }
  }

  onLogin() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString("email", email.text);
    prefs.setString("emailRemember", email.text);
    prefs.setString("password", password.text);
    prefs.setString("passwordRemember", password.text);
    final response = await _authRepository
        .login(LoginRequest(email: email.text, password: password.text));
    response.fold((l) => Get.snackbar('Failed!', "Login Failed"), (r) {
      if (remember.value == true) {
        prefs.setBool("value", true);
      } else {
        prefs.setBool("value", false);
      }

      if (r.data != null) {
        if (r.data?.role == "1") {
          Get.off(() => DashboardForSuperAdminScreen());
        } else if (r.data?.role == "2") {
          Get.off(() => DashboardForAdminScreen());
        } else if (r.data?.role == "3") {
          Get.off(() => DashboardForUserScreen());
        }
      }
    });
  }

  onClickBrand() async {
    final Uri url = Uri.parse('https://www.tradewavetechnology.com/');
    await _launchUrl(url);
  }

  onClickRecoverAccount() async {
    final Uri url = Uri.parse('https://factanalyzer.com/recover/password');
    await _launchUrl(url);
  }

  _launchUrl(Uri url) async {
    if (!await launchUrl(url)) throw 'Could not launch $url';
  }

  @override
  onInit() async {
    super.onInit();
    getRememberMeUser();
  }
}
