import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;
import 'package:lms/app/modules/auth/models/responses/login_response.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../shared/errors/failures.dart';
import '../models/requests/login_request.dart';

abstract class AuthRepository {
  Future<Either<Failure, LoginResponse>> login(LoginRequest loginRequest);

  Future<Either<Failure, Unit>> logout();

  Future<Either<Failure, bool>> isLoggedIn();

  Future<Either<Failure, LoginResponse>> getLoginResponse();

  Future<Either<Failure, Unit>> setLoginResponse(LoginResponse loginResponse);

  Future<Either<Failure, Unit>> removeLoginResponse();
}

class AuthRepositoryImpl implements AuthRepository {
  final SharedPreferences _sharedPreferences;

  final loginResponseKey = 'loginResponse';

  AuthRepositoryImpl(this._sharedPreferences);

  @override
  Future<Either<Failure, LoginResponse>> login(
      LoginRequest loginRequest) async {
    var request = http.MultipartRequest(
        'POST', Uri.parse('https://factanalyzer.com/api/login'));
    request.fields.addAll(loginRequest
        .toMap()
        .map((key, value) => MapEntry(key, value.toString())));

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      final loginResponse =
          LoginResponse.fromJson(await response.stream.bytesToString());
      final setResponse = await setLoginResponse(loginResponse);
      print(setResponse);
      return right(loginResponse);
    } else {
      return left(ApiFailure(
          message: response.reasonPhrase!, code: response.statusCode));
    }
  }

  @override
  Future<Either<Failure, LoginResponse>> getLoginResponse() async {
    final response = _sharedPreferences.getString(loginResponseKey);
    if (response != null) {
      return right(LoginResponse.fromJson(response));
    } else {
      return left(const CacheFailure());
    }
  }

  @override
  Future<Either<Failure, Unit>> setLoginResponse(
      LoginResponse loginResponse) async {
    _sharedPreferences.setString(loginResponseKey, loginResponse.toJson());
    return right(unit);
  }

  @override
  Future<Either<Failure, Unit>> removeLoginResponse() async {
    _sharedPreferences.remove(loginResponseKey);
    return right(unit);
  }

  @override
  Future<Either<Failure, Unit>> logout() async {
    await removeLoginResponse();
    return right(unit);
  }

  @override
  Future<Either<Failure, bool>> isLoggedIn() async {
    final response = await getLoginResponse();

    return response.fold(
      (failure) => left(failure),
      (loginResponse) => right(loginResponse.token != null),
    );
  }
}
