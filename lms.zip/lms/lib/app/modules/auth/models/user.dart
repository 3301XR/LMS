import 'dart:convert';

class User {
  User({
    this.id,
    this.username,
    this.email,
    this.password,
    this.role,
    this.isActive,
    this.phone,
    this.oparetorId,
    this.employeeId,
    this.token,
    this.createdAt,
    this.updatedAt,
  });

  int? id;
  String? username;
  String? email;
  String? password;
  String? role;
  String? isActive;
  String? phone;
  dynamic oparetorId;
  int? employeeId;
  dynamic token;
  dynamic createdAt;
  String? updatedAt;

  factory User.fromJson(String str) => User.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory User.fromMap(Map<String, dynamic> json) => User(
        id: json["id"],
        username: json["username"],
        email: json["email"],
        password: json["password"],
        role: json["role"],
        isActive: json["is_active"],
        phone: json["phone"],
        oparetorId: json["oparetor_id"],
        employeeId: json["employee_id"],
        token: json["token"],
        createdAt: json["created_at"],
        updatedAt: json["updated_at"],
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "username": username,
        "email": email,
        "password": password,
        "role": role,
        "is_active": isActive,
        "phone": phone,
        "oparetor_id": oparetorId,
        "employee_id": employeeId,
        "token": token,
        "created_at": createdAt,
        "updated_at": updatedAt,
      };
}
