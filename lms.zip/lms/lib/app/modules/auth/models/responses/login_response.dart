// To parse this JSON data, do
//
//     final loginResponse = loginResponseFromMap(jsonString);

import 'dart:convert';

import '../user.dart';

class LoginResponse {
  LoginResponse({
    this.message,
    this.token,
    this.data,
  });

  String? message;
  String? token;
  User? data;

  factory LoginResponse.fromJson(String str) =>
      LoginResponse.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory LoginResponse.fromMap(Map<String, dynamic> json) => LoginResponse(
        message: json["message"],
        token: json["token"],
        data: json["data"] == null ? null : User.fromMap(json["data"]),
      );

  Map<String, dynamic> toMap() => {
        "message": message,
        "token": token,
        "data": data?.toMap(),
      };
}
