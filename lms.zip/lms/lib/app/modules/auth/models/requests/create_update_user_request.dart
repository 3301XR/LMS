// To parse this JSON data, do
//
//     final createUserRequest = createUserRequestFromMap(jsonString);

import 'dart:convert';

class CreateUpdateUserRequest {
  CreateUpdateUserRequest({
    this.firstName,
    this.username,
    this.phone,
    this.password,
    this.branch,
    this.department,
    this.email,
    this.role,
    this.isActive,
  });

  String? firstName;
  String? username;
  String? phone;
  String? password;
  String? branch;
  String? department;
  String? email;
  int? role;
  int? isActive;

  factory CreateUpdateUserRequest.fromJson(String str) =>
      CreateUpdateUserRequest.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory CreateUpdateUserRequest.fromMap(Map<String, dynamic> json) =>
      CreateUpdateUserRequest(
        firstName: json["first_name"],
        username: json["username"],
        phone: json["phone"],
        password: json["password"],
        branch: json["branch"],
        department: json["department"],
        email: json["email"],
        role: json["role"],
        isActive: json["is_active"],
      );

  Map<String, dynamic> toMap() => {
        "first_name": firstName,
        "username": username,
        "phone": phone,
        "password": password,
        "branch": branch,
        "department": department,
        "email": email,
        "role": role,
        "is_active": isActive,
      };
}
