import 'package:get/get.dart';
import 'package:lms/app/modules/admin/presentation/views/pages/dashboard_for_admin_screen.dart';
import 'package:lms/app/modules/auth/presentation/views/login_screen.dart';
import 'package:lms/app/modules/auth/repositories/auth_repository.dart';
import 'package:lms/app/modules/employee/presentation/views/pages/dashboard_for_user_screen.dart';
import 'package:lms/app/modules/super_admin/presentation/views/pages/dashboard_for_super_admin_screen.dart';

class SplashController extends GetxController {
  final AuthRepository _authRepository = Get.find<AuthRepository>();

  @override
  void onReady() {
    super.onReady();
    _navigateAfterSplash();
  }

  _navigateAfterSplash() async {
    await Future.delayed(
      const Duration(seconds: 3),
      () async {
        var response = await _authRepository.getLoginResponse();

        response.fold((l) => Get.off(() => LoginScreen()), (r) {
          if (r.data != null) {
            if (r.data?.role == "1") {
              Get.off(() => DashboardForSuperAdminScreen());
            } else if (r.data?.role == "2") {
              Get.off(() => DashboardForAdminScreen());
            } else if (r.data?.role == "3") {
              Get.off(() => DashboardForUserScreen());
            }
          }
        });
      },
    );
  }
}
