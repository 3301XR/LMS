import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lms/app/modules/splash/presentation/controllers/splash_controller.dart';

class SplashPage extends StatelessWidget {
  SplashPage({Key? key}) : super(key: key) {
    _controller = Get.put(SplashController());
  }

  late final SplashController _controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Image.asset("assets/splash.png"),
      ),
    );
  }
}
