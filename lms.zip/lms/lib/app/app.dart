import 'package:flutter/material.dart';
import 'package:lms/app/modules/splash/presentation/views/pages/splash_page.dart';
import 'package:lms/app/shared/values/colors.dart';
import 'package:get/get.dart';

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'LMS',
      theme: AppTheme.primaryTheme,
      home: SplashPage(),
    );
  }
}
